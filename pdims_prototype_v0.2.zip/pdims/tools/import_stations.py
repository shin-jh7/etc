"""해양경찰청_관서현황(공공데이터포털 파일데이터, CSV) → data/stations_imported.json
주소를 브이월드 지오코더로 좌표화한다. 사용:
  python tools/import_stations.py 관서현황.csv
확인 후 필요한 항목을 data/stations.json 에 병합하고 obs_code·warn_areas 를 채운다."""
import csv
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import config  # noqa: E402
from app.integrations import vworld  # noqa: E402


def read_csv(path):
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            with open(path, encoding=enc, newline="") as f:
                return list(csv.DictReader(f))
        except UnicodeDecodeError:
            continue
    raise SystemExit("인코딩을 알 수 없습니다")


def col(row, *pats):
    for k in row:
        if any(re.search(p, k) for p in pats):
            return (row[k] or "").strip()
    return ""


def main(path):
    rows = read_csv(path)
    print("열 목록:", list(rows[0].keys()) if rows else "(없음)")
    out, fail = [], []
    for i, r in enumerate(rows):
        name = col(r, r"파출소|출장소|관서명|명칭")
        addr = col(r, r"주소|소재지")
        office = col(r, r"해양경찰서|경찰서")
        if not name or not re.search(r"파출소|출장소", name):
            continue
        g = vworld.geocode(addr) if addr else {"lat": None}
        rec = {"id": f"ST-{i:04d}", "name": name, "office": office, "type": "station", "address": addr,
               "lat": g.get("lat"), "lon": g.get("lon"), "obs_code": "", "warn_areas": [], "source": "해양경찰청_관서현황"}
        (out if rec["lat"] else fail).append(rec)
    dst = config.DATA_DIR / "stations_imported.json"
    dst.write_text(json.dumps(out + fail, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"좌표화 성공 {len(out)}건, 실패 {len(fail)}건 → {dst}")
    if fail:
        print("실패 예:", [f["name"] + " / " + f["address"] for f in fail[:5]])


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    main(sys.argv[1])
