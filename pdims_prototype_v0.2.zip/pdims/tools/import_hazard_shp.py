"""해양경찰청_연안위험구역현황(공공데이터포털 파일데이터, SHP) → data/hazard_zones.geojson
필요 패키지: pip install -r requirements-tools.txt  (pyshp, pyproj)
사용: python tools/import_hazard_shp.py 연안위험구역.shp [--encoding cp949] [--replace]
.prj 로 좌표계를 판별해 WGS84(EPSG:4326)로 변환. 폴리곤은 대표점(무게중심)을 순찰 지점으로 사용하고 원형 폴리곤도 보존."""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import config  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("shp")
    ap.add_argument("--encoding", default="cp949")
    ap.add_argument("--replace", action="store_true", help="기존 hazard_zones.geojson 을 교체")
    a = ap.parse_args()
    import shapefile
    from pyproj import CRS, Transformer
    prj = Path(a.shp).with_suffix(".prj")
    src = CRS.from_wkt(prj.read_text(encoding="utf-8", errors="ignore")) if prj.exists() else CRS.from_epsg(5186)
    tf = Transformer.from_crs(src, CRS.from_epsg(4326), always_xy=True)
    sf = shapefile.Reader(a.shp, encoding=a.encoding)
    fields = [f[0] for f in sf.fields[1:]]
    print("속성 필드:", fields)
    feats = []
    for i, sr in enumerate(sf.shapeRecords()):
        props = dict(zip(fields, sr.record))
        pts = [tf.transform(x, y) for x, y in sr.shape.points]
        if not pts:
            continue
        name = next((str(props[k]) for k in props if any(s in k.upper() for s in ("NAME", "NM", "명"))), f"위험구역{i+1}")
        cx = sum(p[0] for p in pts) / len(pts)
        cy = sum(p[1] for p in pts) / len(pts)
        feats.append({"type": "Feature", "properties": {"id": f"HZ-{i+1:04d}", "name": name, "risk": str(props.get("RISK", props.get("구분", ""))),
                                                          "source": "해양경찰청_연안위험구역현황", "attrs": props},
                      "geometry": {"type": "Point", "coordinates": [round(cx, 6), round(cy, 6)]}})
    fc = {"type": "FeatureCollection", "name": "hazard_zones(해양경찰청)", "features": feats}
    dst = config.DATA_DIR / ("hazard_zones.geojson" if a.replace else "hazard_zones_imported.geojson")
    dst.write_text(json.dumps(fc, ensure_ascii=False, default=str, indent=1), encoding="utf-8")
    print(f"{len(feats)}건 → {dst}  (좌표계: {src.name})")


if __name__ == "__main__":
    main()
