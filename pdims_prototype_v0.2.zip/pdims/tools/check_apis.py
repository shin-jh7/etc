"""연계 점검 도구: .env 의 키로 각 API를 실제 호출해 결과·응답 필드를 출력한다.
사용: python tools/check_apis.py   (결과는 cache/api_check_report.json 에도 저장)"""
import json
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import config, geo  # noqa: E402
from app.integrations import base, kma, khoa, astro, vworld  # noqa: E402

LAT, LON = 37.2525, 126.4700   # 영흥(예시)
OBS = "DT_0001"
report = []


def run(name, fn):
    t0 = time.time()
    try:
        detail = fn()
        ok = True
    except Exception as e:
        detail, ok = f"{type(e).__name__}: {e}", False
    ms = round((time.time() - t0) * 1000)
    report.append({"service": name, "ok": ok, "ms": ms, "detail": detail})
    mark = "OK  " if ok else "FAIL"
    print(f"[{mark}] {name} ({ms}ms)")
    print("       " + (json.dumps(detail, ensure_ascii=False)[:600] if not isinstance(detail, str) else detail[:600]))


def dgk(url, params):
    text = base.http_get(url, {"serviceKey": config.DATA_GO_KR_KEY, **params})
    items = base.parse_data_go_kr_json(text)
    return {"items": len(items), "fields": sorted(items[0].keys()) if items else [], "sample": items[:2]}


def main():
    print("DATA_GO_KR_KEY:", base.mask(config.DATA_GO_KR_KEY), "| VWORLD_API_KEY:", base.mask(config.VWORLD_API_KEY),
          "| VWORLD_DOMAIN:", config.VWORLD_DOMAIN)
    nx, ny = geo.latlon_to_grid(LAT, LON)
    d, t = kma.base_ncst()
    vd, vt = kma.base_vilage()
    ud, ut = kma.base_ultra_fcst()
    today = datetime.now().strftime("%Y%m%d")
    run("① 기상청 초단기실황", lambda: dgk(kma.BASE + "/getUltraSrtNcst", {"pageNo": 1, "numOfRows": 20, "dataType": "JSON", "base_date": d, "base_time": t, "nx": nx, "ny": ny}))
    run("① 기상청 초단기예보", lambda: dgk(kma.BASE + "/getUltraSrtFcst", {"pageNo": 1, "numOfRows": 10, "dataType": "JSON", "base_date": ud, "base_time": ut, "nx": nx, "ny": ny}))
    run("① 기상청 단기예보", lambda: dgk(kma.BASE + "/getVilageFcst", {"pageNo": 1, "numOfRows": 10, "dataType": "JSON", "base_date": vd, "base_time": vt, "nx": nx, "ny": ny}))
    run("② 기상청 기상특보 특보현황", lambda: dgk(kma.WARN + "/getPwnStatus", {"pageNo": 1, "numOfRows": 5, "dataType": "JSON"}))
    for k, url in khoa.ENDPOINTS.items():
        run(f"③ 국립해양조사원 {k}", lambda url=url, k=k: dgk(url, {"type": "json", "obsCode": OBS, "reqDate": today, "pageNo": 1, "numOfRows": 5, **({"min": 60} if k != "hilo" else {})}))
    run("④ 천문연 출몰시각", lambda: astro.parse_xml(base.http_get(astro.URL, {"serviceKey": config.DATA_GO_KR_KEY, "locdate": today, "longitude": LON, "latitude": LAT, "dnYn": "Y"})))
    run("V① 브이월드 WMTS Base 타일", lambda: {"bytes": len(vworld.tile("Base", 12, 1587, 3490)[0])})
    run("V① 브이월드 WMTS Satellite 타일", lambda: {"bytes": len(vworld.tile("Satellite", 12, 1587, 3490)[0])})
    box = (126.40, 37.20, 126.60, 37.32)
    run("V② 브이월드 행정경계 시군구", lambda: _fc(vworld.ADMIN_LAYERS["sigungu"], box))
    for code, kind in vworld.AIRSPACE_LAYERS.items():
        run(f"V③ 브이월드 공역 {kind}({code})", lambda code=code: _fc(code, (125.5, 36.5, 127.5, 38.0)))
    run("V④ 브이월드 지오코더", lambda: _geo("인천광역시 옹진군 영흥면 영흥남로 1"))
    run("V④ 브이월드 검색", lambda: _search("영흥도"))
    out = Path(config.CACHE_DIR) / "api_check_report.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    ok = sum(r["ok"] for r in report)
    print(f"\n결과: {ok}/{len(report)} 성공 → {out}")
    print("실패 항목은 (1) 공공데이터포털 서비스별 활용신청 승인 여부, (2) 브이월드 키의 등록 도메인·활용 API 체크, (3) 방화벽/프록시를 확인하세요.")


def _fc(layer, box):
    params = {"service": "data", "request": "GetFeature", "data": layer, "key": config.VWORLD_API_KEY, "domain": config.VWORLD_DOMAIN,
              "format": "json", "crs": "EPSG:4326", "size": 5, "page": 1, "geometry": "false", "attribute": "true",
              "geomFilter": "BOX(%s,%s,%s,%s)" % box}
    fc = vworld.parse_data_response(base.http_get(vworld.DATA, params))
    feats = fc.get("features", [])
    return {"features": len(feats), "fields": sorted(feats[0].get("properties", {}).keys()) if feats else []}


def _geo(addr):
    return json.loads(base.http_get(vworld.ADDRESS, {"service": "address", "request": "getcoord", "version": "2.0", "crs": "epsg:4326",
                                                     "address": addr, "refine": "true", "simple": "false", "format": "json", "type": "road",
                                                     "key": config.VWORLD_API_KEY})).get("response", {})


def _search(q):
    r = json.loads(base.http_get(vworld.SEARCH, {"service": "search", "request": "search", "version": "2.0", "crs": "EPSG:4326", "size": 3,
                                                 "page": 1, "query": q, "type": "place", "format": "json", "errorformat": "json",
                                                 "key": config.VWORLD_API_KEY})).get("response", {})
    return {"status": r.get("status"), "count": (r.get("record") or {}).get("total"), "error": r.get("error")}


if __name__ == "__main__":
    main()
