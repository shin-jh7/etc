"""간이 JSON 저장소 (프로토타입). 정식 버전은 PostgreSQL/PostGIS."""
import json
import threading
from app import config

_lock = threading.Lock()


def read(name, default=None):
    p = config.DATA_DIR / name
    if not p.exists():
        return default
    return json.loads(p.read_text(encoding="utf-8"))


def write(name, obj):
    with _lock:
        p = config.DATA_DIR / name
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
