"""API 핸들러에서 호출하는 업무 로직 (FastAPI 비의존 → 단독 테스트 가능)."""
import uuid
from datetime import datetime
from app import store, geo
from app.core import judge as J, schedule, routes, jurisdiction
from app.integrations import kma, khoa, astro, vworld
from app.core import sun


def stations():
    return store.read("stations.json", [])


def station(sid):
    st = next((s for s in stations() if s["id"] == sid), None)
    if not st:
        raise KeyError(f"station {sid} 없음")
    return st


def drones():
    return store.read("drones.json", [])


def drone(did):
    d = next((x for x in drones() if x["id"] == did), None)
    if not d:
        raise KeyError(f"drone {did} 없음")
    return d


def add_drone(d):
    ds = drones()
    d = dict(d)
    d["id"] = d.get("id") or "D-" + uuid.uuid4().hex[:6].upper()
    ds = [x for x in ds if x["id"] != d["id"]] + [d]
    store.write("drones.json", ds)
    return d


def delete_drone(did):
    ds = [x for x in drones() if x["id"] != did]
    store.write("drones.json", ds)
    return {"deleted": did}


def _meta(x):
    return (x or {}).get("_meta", {})


def conditions(sid):
    """현재 기상·특보·일출몰·물때 종합 (FR-03)."""
    st = station(sid)
    cur = kma.current(st["lat"], st["lon"])
    warn = kma.warnings_for(st)
    sn = astro.sun_info(st["lat"], st["lon"])
    td = khoa.tide(st.get("obs_code"))
    now = datetime.now()
    night = sun.is_night(now, sn)
    wx = dict(cur["now"])
    wx["stale"] = _meta(cur).get("source") in ("stale", "mock-fallback")
    upcoming = [e for e in td.get("events", []) if e["time"] >= now.isoformat(timespec="minutes")][:4]
    return {"station": st, "weather": wx, "warnings": warn["warnings"], "sun": sn, "night": night,
            "tide": {"obs_code": st.get("obs_code"), "events": td.get("events", []), "upcoming": upcoming},
            "sources": {"weather": _meta(cur), "warnings": _meta(warn), "sun": _meta(sn), "tide": _meta(td)}}


def judge_now(sid, did):
    c = conditions(sid)
    d = drone(did)
    j = J.judge(c["weather"], d, warnings=c["warnings"], night=c["night"], ship_based=c["station"].get("type") == "ship")
    return {**j, "conditions": c, "drone": d}


def schedule_rec(sid, did, hours=72, duration=1, mission="patrol"):
    st, d = station(sid), drone(did)
    fc = kma.hourly(st["lat"], st["lon"], hours)
    warn = kma.warnings_for(st)
    days = max(1, (hours + 23) // 24 + 1)
    td = khoa.tide(st.get("obs_code"), days=days)
    rec = schedule.recommend(fc["hours"], d, warn["warnings"], st, td.get("events"), duration, mission)
    return {**rec, "sources": {"forecast": _meta(fc), "tide": _meta(td), "warnings": _meta(warn)}}


def _bbox_of(points, pad=0.05):
    las, los = [p[0] for p in points], [p[1] for p in points]
    return (min(los) - pad, min(las) - pad, max(los) + pad, max(las) + pad)


def plan_mission(req):
    """req: {type: route|patrol|search, station, drone, alt_m, route_id | hazard_ids | datum, pattern...}"""
    st, d = station(req["station"]), drone(req["drone"])
    base_pt = (st["lat"], st["lon"])
    alt = float(req.get("alt_m", 100))
    hover_s, hover_points = 0, []
    kind = req.get("type", "route")
    if kind == "route":
        r = next(x for x in store.read("routes.json", []) if x["id"] == req["route_id"])
        wps = [tuple(p) for p in r["waypoints"]]
        name = r["name"]
    elif kind == "patrol":
        hz = {f["properties"]["id"]: f for f in store.read("hazard_zones.geojson")["features"]}
        sel = [hz[h] for h in req.get("hazard_ids", []) if h in hz]
        if not sel:
            raise ValueError("위험지점을 1개 이상 선택하세요")
        pts = [(f["geometry"]["coordinates"][1], f["geometry"]["coordinates"][0]) for f in sel]
        order = routes.tsp_route(base_pt, pts)
        wps = [pts[i] for i in order]
        hover_per = int(req.get("hover_s", 60))
        hover_s = hover_per * len(wps)
        hover_points = list(range(len(wps)))
        name = "위험구역 순찰: " + " → ".join(sel[i]["properties"]["name"] for i in order)
    elif kind == "search":
        la, lo = req["datum"]
        wps = routes.search_pattern(req.get("pattern", "SS"), la, lo, spacing=float(req.get("spacing", 200)),
                                    legs=int(req.get("legs", 12)), radius=float(req.get("radius", 1000)),
                                    width=float(req.get("width", 2000)), length=float(req.get("length", 2000)),
                                    brg=float(req.get("bearing", 0)))
        name = f'해상 수색 {req.get("pattern","SS")} (기준점 {la:.4f},{lo:.4f})'
    else:
        raise ValueError("type 은 route/patrol/search")
    full = [base_pt] + list(wps) + [base_pt]
    cur = kma.current(st["lat"], st["lon"])
    wind = cur["now"].get("wind") or 0
    air = None
    if req.get("check_airspace", True):
        air = vworld.airspace(_bbox_of(full))
    v = routes.validate(full, d, st, alt, wind, hover_s,
                        jurisdiction_check=lambda pts: jurisdiction.outside_points(st["id"], pts[1:-1]), airspace=air)
    # 관할 이탈 index 는 wps 기준
    return {"name": name, "type": kind, "station": st["id"], "drone": d["id"], "alt_m": alt,
            "waypoints": [list(p) for p in wps], "full_path": [list(p) for p in full],
            "hover_s": int(req.get("hover_s", 60)) if kind == "patrol" else 0,
            "hover_points": hover_points, "validation": v, "wind": wind, "wind_dir": cur["now"].get("wind_dir"),
            "airspace_source": (air or {}).get("_meta")}
