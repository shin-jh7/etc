"""환경설정: .env 파일을 python-dotenv 없이 직접 읽는다."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = BASE_DIR / "cache"
STATIC_DIR = BASE_DIR / "static"


def _load_env(path: Path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'")
        os.environ.setdefault(k, v)


_load_env(BASE_DIR / ".env")


def env(name, default=""):
    return os.environ.get(name, default).strip()


# 공공데이터포털 일반 인증키 (기상청 단기예보·기상특보, 국립해양조사원, 천문연구원 공통)
DATA_GO_KR_KEY = env("DATA_GO_KR_KEY")
# 브이월드 인증키 / 등록 도메인
VWORLD_API_KEY = env("VWORLD_API_KEY")
VWORLD_DOMAIN = env("VWORLD_DOMAIN", "http://localhost:8000")
# tile 모드: proxy(서버 경유, 키 숨김·캐시) / direct(브라우저가 직접 호출)
VWORLD_TILE_MODE = env("VWORLD_TILE_MODE", "proxy")
# 강제 mock 모드 (1 이면 외부 호출 안 함)
FORCE_MOCK = env("PDIMS_FORCE_MOCK", "0") == "1"
HTTP_TIMEOUT = float(env("PDIMS_HTTP_TIMEOUT", "8"))
CAUTION_RATIO = float(env("PDIMS_CAUTION_RATIO", "0.8"))
DEFAULT_STATION = env("PDIMS_DEFAULT_STATION", "ST-YH")
