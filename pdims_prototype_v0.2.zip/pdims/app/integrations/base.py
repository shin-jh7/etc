"""연계 공통: HTTP 호출, TTL 캐시, 연계 상태(성공률·응답시간) 기록, 키 마스킹."""
import json
import time
import threading
import urllib.parse
import urllib.request
import urllib.error
from app import config

_cache = {}
_lock = threading.Lock()
STATUS = {}
FAIL_UNTIL = {}          # 서비스별 재시도 대기(서킷 브레이커): 실패 후 60초간 외부 호출 생략
RETRY_AFTER_S = 60


class ApiError(Exception):
    pass


def mask(key: str):
    if not key:
        return "(미설정)"
    return key[:4] + "*" * 8 + key[-4:]


def _stat(service):
    return STATUS.setdefault(service, {"calls": 0, "ok": 0, "fail": 0, "avg_ms": 0,
                                       "last_ok": None, "last_error": None, "last_error_at": None, "mode": "mock"})


def record(service, ok, ms=0, err=None, mode=None):
    s = _stat(service)
    s["calls"] += 1
    if ok:
        s["ok"] += 1
        s["last_ok"] = time.strftime("%Y-%m-%d %H:%M:%S")
        s["avg_ms"] = round((s["avg_ms"] * (s["ok"] - 1) + ms) / s["ok"])
    else:
        s["fail"] += 1
        s["last_error"] = str(err)[:300]
        s["last_error_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    if mode:
        s["mode"] = mode


def build_url(url, params):
    # serviceKey 는 이미 인코딩된 값일 수 있으므로 safe 처리 (64자리 hex 키는 영향 없음)
    q = []
    for k, v in params.items():
        if v is None:
            continue
        safe = "%" if k == "serviceKey" else ""
        q.append(f"{k}={urllib.parse.quote(str(v), safe=safe)}")
    return url + ("&" if "?" in url else "?") + "&".join(q)


def http_get(url, params=None, headers=None, timeout=None, raw=False):
    full = build_url(url, params or {})
    req = urllib.request.Request(full, headers={"User-Agent": "PDIMS/0.2", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout or config.HTTP_TIMEOUT) as r:
            body = r.read()
            ctype = r.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        raise ApiError(f"HTTP {e.code}: {e.read()[:200]!r}")
    except Exception as e:
        raise ApiError(f"연결 실패: {e}")
    if raw:
        return body, ctype
    text = body.decode("utf-8", errors="replace")
    return text


def cached(key, ttl, fn):
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < ttl:
            return hit[1]
    val = fn()
    with _lock:
        _cache[key] = (now, val)
    return val


def stale(key):
    """API 장애 시 마지막 캐시값 반환 (계획서 5장: 최근 수집값 + 지연 배지)."""
    hit = _cache.get(key)
    return (hit[1], time.strftime("%H:%M", time.localtime(hit[0]))) if hit else (None, None)


def call(service, key, ttl, live_fn, mock_fn, enabled=True):
    """live 호출 → 실패 시 마지막 캐시 → 그래도 없으면 mock. 결과에 _meta 부착."""
    if not enabled or config.FORCE_MOCK:
        _stat(service)["mode"] = "mock"
        v = mock_fn()
        return {**v, "_meta": {"source": "mock", "service": service}} if isinstance(v, dict) else v
    if time.time() < FAIL_UNTIL.get(service, 0):
        old, at = stale(key)
        err = f"최근 호출 실패로 재시도 대기 중: {_stat(service).get('last_error')}"
        if old is not None:
            return {**old, "_meta": {"source": "stale", "service": service, "collected_at": at, "error": err}}
        v = mock_fn()
        return {**v, "_meta": {"source": "mock-fallback", "service": service, "error": err}}
    try:
        def run():
            t0 = time.time()
            v = live_fn()
            record(service, True, (time.time() - t0) * 1000, mode="live")
            FAIL_UNTIL.pop(service, None)
            return v
        v = cached(key, ttl, run)
        return {**v, "_meta": {"source": "live", "service": service}} if isinstance(v, dict) else v
    except Exception as e:
        record(service, False, err=e, mode="error")
        FAIL_UNTIL[service] = time.time() + RETRY_AFTER_S
        old, at = stale(key)
        if old is not None:
            return {**old, "_meta": {"source": "stale", "service": service, "collected_at": at, "error": str(e)[:200]}}
        v = mock_fn()
        return {**v, "_meta": {"source": "mock-fallback", "service": service, "error": str(e)[:200]}}


def parse_data_go_kr_json(text):
    """공공데이터포털 표준 응답 → item 리스트. 오류코드면 ApiError."""
    t = text.strip()
    if t.startswith("<"):
        # 키 오류 등은 XML(OpenAPI_ServiceResponse)로 옴
        import re
        msg = re.search(r"<returnAuthMsg>(.*?)</returnAuthMsg>", t) or re.search(r"<resultMsg>(.*?)</resultMsg>", t)
        code = re.search(r"<returnReasonCode>(.*?)</returnReasonCode>", t) or re.search(r"<resultCode>(.*?)</resultCode>", t)
        if code and code.group(1) not in ("00", "0"):
            raise ApiError(f"공공데이터포털 오류 {code.group(1)}: {msg.group(1) if msg else ''}")
        raise ApiError("JSON 대신 XML 응답: " + t[:150])
    j = json.loads(t)
    resp = j.get("response", j)
    head = resp.get("header", {})
    code = str(head.get("resultCode", "00"))
    if code not in ("00", "0", "INFO-000"):
        raise ApiError(f'결과코드 {code}: {head.get("resultMsg")}')
    body = resp.get("body", {})
    items = body.get("items", {})
    if isinstance(items, dict):
        items = items.get("item", [])
    if isinstance(items, dict):
        items = [items]
    return items or []
