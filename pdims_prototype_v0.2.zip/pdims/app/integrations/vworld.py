"""브이월드: 배경·위성·하이브리드 WMTS, 2D 데이터 API(행정경계·항공 공역), 지오코더·검색."""
import json
from app import config
from app.integrations import base

WMTS = "https://api.vworld.kr/req/wmts/1.0.0/{key}/{layer}/{z}/{y}/{x}.{ext}"
TILE_LAYERS = {"Base": "png", "Satellite": "jpeg", "Hybrid": "png", "gray": "png", "midnight": "png"}
DATA = "https://api.vworld.kr/req/data"
ADDRESS = "https://api.vworld.kr/req/address"
SEARCH = "https://api.vworld.kr/req/search"

ADMIN_LAYERS = {"sido": "LT_C_ADSIDO_INFO", "sigungu": "LT_C_ADSIGG_INFO", "emd": "LT_C_ADEMD_INFO"}
# 항공·공역 레이어 (브이월드 데이터 목록 기준, check_apis.py 로 레이어별 응답 확인)
AIRSPACE_LAYERS = {
    "LT_C_AISPRHC": "비행금지구역",
    "LT_C_AISRESC": "비행제한구역",
    "LT_C_AISDNGC": "위험구역",
    "LT_C_AISCTRC": "관제권",
    "LT_C_AISMOAC": "군작전구역",
    "LT_C_AISUAC": "초경량비행장치공역",
}
NAME_KEYS = ["prh_lbl_1", "res_lbl_1", "dng_lbl_1", "ctr_lbl_1", "moa_lbl_1", "uac_lbl_1",
             "full_nm", "ctp_kor_nm", "sig_kor_nm", "emd_kor_nm", "name", "nam", "label"]


def enabled():
    return bool(config.VWORLD_API_KEY)


def tile(layer, z, y, x):
    if layer not in TILE_LAYERS:
        raise base.ApiError("unknown layer")
    url = WMTS.format(key=config.VWORLD_API_KEY, layer=layer, z=z, y=y, x=x, ext=TILE_LAYERS[layer])
    key = f"tile:{layer}:{z}:{y}:{x}"

    def fetch():
        body, ctype = base.http_get(url, headers={"Referer": config.VWORLD_DOMAIN}, raw=True)
        if not ctype.startswith("image"):
            raise base.ApiError("타일 대신 비이미지 응답: " + body[:150].decode("utf-8", "replace"))
        return (body, ctype)

    try:
        v = base.cached(key, 7 * 24 * 3600, fetch)
        base.record("vworld_wmts", True, 0, mode="live")
        return v
    except Exception as e:
        base.record("vworld_wmts", False, err=e, mode="error")
        raise


def _name(props):
    for k in NAME_KEYS:
        if props.get(k):
            return str(props[k])
    for k, v in props.items():
        if ("nm" in k.lower() or "lbl" in k.lower()) and v:
            return str(v)
    return "-"


def parse_data_response(text):
    j = json.loads(text)
    r = j.get("response", {})
    st = r.get("status")
    if st == "NOT_FOUND":
        return {"type": "FeatureCollection", "features": []}
    if st != "OK":
        raise base.ApiError(f'브이월드 {st}: {(r.get("error") or {}).get("text", "")}')
    fc = r.get("result", {}).get("featureCollection", {"type": "FeatureCollection", "features": []})
    return fc


def get_features(layer, bbox, size=1000, service="vworld_data"):
    minx, miny, maxx, maxy = [round(float(v), 5) for v in bbox]
    params = {"service": "data", "request": "GetFeature", "data": layer, "key": config.VWORLD_API_KEY,
              "domain": config.VWORLD_DOMAIN, "format": "json", "crs": "EPSG:4326", "size": size, "page": 1,
              "geometry": "true", "attribute": "true", "geomFilter": f"BOX({minx},{miny},{maxx},{maxy})"}

    def live():
        return parse_data_response(base.http_get(DATA, params))

    return base.call(service, f"data:{layer}:{minx}:{miny}:{maxx}:{maxy}", 24 * 3600, live,
                     lambda: {"type": "FeatureCollection", "features": []}, enabled())


def admin_boundary(level, bbox):
    fc = get_features(ADMIN_LAYERS[level], bbox, service="vworld_admin")
    for f in fc.get("features", []):
        f.setdefault("properties", {})["_name"] = _name(f["properties"])
    return fc


def airspace(bbox, layers=None):
    """항공 공역 레이어를 합쳐 하나의 FeatureCollection 으로 반환 (_kind, _name 부여)."""
    feats, meta = [], {}
    for code, kind in AIRSPACE_LAYERS.items():
        if layers and code not in layers:
            continue
        fc = get_features(code, bbox, service="vworld_airspace")
        meta[code] = (fc.get("_meta") or {}).get("source")
        for f in fc.get("features", []):
            pr = f.setdefault("properties", {})
            pr["_kind"], pr["_name"], pr["_layer"] = kind, _name(pr), code
            feats.append(f)
    return {"type": "FeatureCollection", "features": feats, "_meta": {"layers": meta, "service": "vworld_airspace"}}


def geocode(address):
    def live():
        for typ in ("road", "parcel"):
            j = json.loads(base.http_get(ADDRESS, {"service": "address", "request": "getcoord", "version": "2.0",
                                                   "crs": "epsg:4326", "address": address, "refine": "true",
                                                   "simple": "false", "format": "json", "type": typ,
                                                   "key": config.VWORLD_API_KEY}))
            r = j.get("response", {})
            if r.get("status") == "OK":
                p = r["result"]["point"]
                return {"address": address, "lat": float(p["y"]), "lon": float(p["x"]), "type": typ,
                        "refined": (r.get("refined") or {}).get("text")}
            if r.get("status") == "ERROR":
                raise base.ApiError((r.get("error") or {}).get("text", "지오코더 오류"))
        return {"address": address, "lat": None, "lon": None, "type": None}

    return base.call("vworld_geocoder", f"geo:{address}", 30 * 24 * 3600, live,
                     lambda: {"address": address, "lat": None, "lon": None}, enabled())


def reverse(lat, lon):
    def live():
        j = json.loads(base.http_get(ADDRESS, {"service": "address", "request": "getAddress", "version": "2.0",
                                               "crs": "epsg:4326", "point": f"{lon},{lat}", "format": "json",
                                               "type": "both", "key": config.VWORLD_API_KEY}))
        r = j.get("response", {})
        if r.get("status") == "OK":
            return {"lat": lat, "lon": lon, "addresses": [x.get("text") for x in r.get("result", [])]}
        if r.get("status") == "NOT_FOUND":
            return {"lat": lat, "lon": lon, "addresses": ["(해상 또는 주소 없음)"]}
        raise base.ApiError((r.get("error") or {}).get("text", "역지오코딩 오류"))

    return base.call("vworld_geocoder", f"rev:{round(lat,5)}:{round(lon,5)}", 24 * 3600, live,
                     lambda: {"lat": lat, "lon": lon, "addresses": []}, enabled())


def search(query, kind="place"):
    def live():
        p = {"service": "search", "request": "search", "version": "2.0", "crs": "EPSG:4326", "size": 10, "page": 1,
             "query": query, "type": kind, "format": "json", "errorformat": "json", "key": config.VWORLD_API_KEY}
        if kind == "address":
            p["category"] = "road"
        j = json.loads(base.http_get(SEARCH, p))
        r = j.get("response", {})
        if r.get("status") == "NOT_FOUND":
            return {"items": []}
        if r.get("status") != "OK":
            raise base.ApiError((r.get("error") or {}).get("text", "검색 오류"))
        items = []
        for it in r["result"]["items"]:
            pt = it.get("point", {})
            title = it.get("title") or (it.get("address") or {}).get("road") or (it.get("address") or {}).get("parcel")
            items.append({"title": title, "category": it.get("category"),
                          "address": (it.get("address") or {}).get("road") or (it.get("address") or {}).get("parcel"),
                          "lat": float(pt.get("y")), "lon": float(pt.get("x"))})
        return {"items": items}

    return base.call("vworld_search", f"search:{kind}:{query}", 24 * 3600, live, lambda: {"items": []}, enabled())
