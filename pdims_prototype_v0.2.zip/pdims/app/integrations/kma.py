"""기상청 단기예보 조회서비스(초단기실황·초단기예보·단기예보) + 기상특보 조회서비스 (공공데이터포털)."""
import math
import re
from datetime import datetime, timedelta
from app import config, geo
from app.integrations import base

BASE = "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0"
WARN = "http://apis.data.go.kr/1360000/WthrWrnInfoService"
GUST_FACTOR = 1.4  # 순간풍속 미제공 → 풍속 × 1.4 추정


def _now():
    return datetime.now()


# ---------- 발표시각 계산 ----------
def base_ncst(now=None):
    now = now or _now()
    t = now if now.minute >= 40 else now - timedelta(hours=1)
    return t.strftime("%Y%m%d"), t.strftime("%H00")


def base_ultra_fcst(now=None):
    now = now or _now()
    t = now if now.minute >= 45 else now - timedelta(hours=1)
    return t.strftime("%Y%m%d"), t.strftime("%H30")


def base_vilage(now=None):
    now = now or _now()
    t = now - timedelta(minutes=15)
    hours = [2, 5, 8, 11, 14, 17, 20, 23]
    cand = [h for h in hours if h <= t.hour]
    if not cand:
        t = t - timedelta(days=1)
        h = 23
    else:
        h = cand[-1]
    return t.strftime("%Y%m%d"), f"{h:02d}00"


# ---------- 값 해석 ----------
def parse_precip(v):
    if v is None:
        return None
    s = str(v).strip()
    if s in ("강수없음", "0", "0.0", "-", ""):
        return 0.0
    if "미만" in s:
        return 0.5
    nums = re.findall(r"[\d.]+", s)
    if not nums:
        return None
    vals = [float(x) for x in nums]
    return max(vals) if "~" in s or "이상" in s else vals[0]


def _f(v):
    try:
        x = float(v)
        return None if x in (-999, 900, 999) or x > 900 else x
    except Exception:
        return None


def _params(date, time, nx, ny, rows=1000):
    return {"serviceKey": config.DATA_GO_KR_KEY, "pageNo": 1, "numOfRows": rows, "dataType": "JSON",
            "base_date": date, "base_time": time, "nx": nx, "ny": ny}


def normalize_ncst(items):
    d = {i["category"]: i.get("obsrValue") for i in items}
    wind = _f(d.get("WSD"))
    return {"time": _now().replace(minute=0, second=0, microsecond=0).isoformat(timespec="minutes"),
            "temp": _f(d.get("T1H")), "wind": wind, "wind_dir": _f(d.get("VEC")),
            "gust": round(wind * GUST_FACTOR, 1) if wind is not None else None,
            "precip": parse_precip(d.get("RN1")), "humidity": _f(d.get("REH")), "pty": d.get("PTY"),
            "visibility_km": None, "wave": None, "estimated": ["순간풍속"]}


def normalize_fcst(items):
    """초단기예보/단기예보 item → 시간별 dict 목록."""
    by = {}
    for i in items:
        k = i["fcstDate"] + i["fcstTime"]
        by.setdefault(k, {})[i["category"]] = i["fcstValue"]
    out = []
    for k in sorted(by):
        d = by[k]
        ts = datetime.strptime(k, "%Y%m%d%H%M")
        wind = _f(d.get("WSD"))
        out.append({"time": ts.isoformat(timespec="minutes"),
                    "temp": _f(d.get("TMP", d.get("T1H"))), "wind": wind, "wind_dir": _f(d.get("VEC")),
                    "gust": round(wind * GUST_FACTOR, 1) if wind is not None else None,
                    "precip": parse_precip(d.get("PCP", d.get("RN1"))), "pop": _f(d.get("POP")),
                    "sky": d.get("SKY"), "pty": d.get("PTY"), "humidity": _f(d.get("REH")),
                    "wave": _f(d.get("WAV")), "visibility_km": None, "estimated": ["순간풍속"]})
    return out


# ---------- mock ----------
def _mock_hour(ts, lat):
    h = ts.hour + ts.day * 24
    wind = round(5 + 4 * math.sin(h / 7.0) + 2 * math.sin(h / 2.3), 1)
    wind = max(0.5, wind)
    return {"time": ts.isoformat(timespec="minutes"), "temp": round(18 + 5 * math.sin((ts.hour - 9) / 24 * 2 * math.pi), 1),
            "wind": wind, "wind_dir": (h * 17) % 360, "gust": round(wind * GUST_FACTOR, 1),
            "precip": 2.0 if (h % 29) in (10, 11, 12) else 0.0, "pop": 60 if (h % 29) in (9, 10, 11, 12) else 10,
            "sky": "1", "pty": "0", "humidity": 70, "wave": round(0.4 + wind / 12, 1),
            "visibility_km": None, "estimated": ["순간풍속", "(mock)"]}


def mock_now(lat):
    return _mock_hour(_now().replace(minute=0, second=0, microsecond=0), lat)


def mock_hourly(lat, hours=72):
    t0 = _now().replace(minute=0, second=0, microsecond=0)
    return [_mock_hour(t0 + timedelta(hours=i), lat) for i in range(hours)]


# ---------- 공개 함수 ----------
def current(lat, lon):
    nx, ny = geo.latlon_to_grid(lat, lon)
    d, t = base_ncst()

    def live():
        items = base.parse_data_go_kr_json(base.http_get(BASE + "/getUltraSrtNcst", _params(d, t, nx, ny, 100)))
        if not items:
            raise base.ApiError("초단기실황 item 없음")
        wx = normalize_ncst(items)
        # 파고는 실황에 없으므로 단기예보 첫 시간값 보강
        try:
            hr = hourly(lat, lon, 6).get("hours", [])
            if hr:
                wx["wave"] = next((h["wave"] for h in hr if h.get("wave") is not None), None)
        except Exception:
            pass
        return {"now": wx, "grid": [nx, ny], "base": d + t}

    return base.call("kma_ncst", f"ncst:{nx}:{ny}:{d}{t}", 600, live,
                     lambda: {"now": mock_now(lat), "grid": [nx, ny], "base": d + t}, bool(config.DATA_GO_KR_KEY))


def hourly(lat, lon, hours=72):
    nx, ny = geo.latlon_to_grid(lat, lon)
    d, t = base_vilage()
    ud, ut = base_ultra_fcst()

    def live():
        items = base.parse_data_go_kr_json(base.http_get(BASE + "/getVilageFcst", _params(d, t, nx, ny, 1000)))
        rows = normalize_fcst(items)
        # 앞쪽 6시간은 초단기예보로 덮어쓰기 (정확도↑). 실패해도 단기예보만 사용
        try:
            u = normalize_fcst(base.parse_data_go_kr_json(base.http_get(BASE + "/getUltraSrtFcst", _params(ud, ut, nx, ny, 100))))
            um = {r["time"]: r for r in u}
            rows = [{**r, **{k: v for k, v in um.get(r["time"], {}).items() if v is not None and k != "wave"}} for r in rows]
        except Exception:
            pass
        now = _now().replace(minute=0, second=0, microsecond=0)
        rows = [r for r in rows if datetime.fromisoformat(r["time"]) >= now][:hours]
        if not rows:
            raise base.ApiError("단기예보 item 없음")
        return {"hours": rows, "grid": [nx, ny], "base": d + t}

    return base.call("kma_fcst", f"fcst:{nx}:{ny}:{d}{t}:{hours}", 1800, live,
                     lambda: {"hours": mock_hourly(lat, hours), "grid": [nx, ny], "base": d + t}, bool(config.DATA_GO_KR_KEY))


# ---------- 기상특보 ----------
def parse_pwn_status(items):
    """getPwnStatus 의 t6(발효현황) 텍스트 → [{name, areas}]"""
    out = []
    for it in items:
        text = str(it.get("t6") or "")
        for line in re.split(r"[\r\n]+", text):
            line = line.strip().lstrip("o").strip()
            if ":" not in line:
                continue
            name, areas = line.split(":", 1)
            name = name.strip()
            if "주의보" in name or "경보" in name or "태풍" in name:
                out.append({"name": name, "areas": areas.strip(), "tmFc": it.get("tmFc")})
    return out


def match_warnings(parsed, keywords):
    hit = []
    for p in parsed:
        if any(k and k in p["areas"] for k in keywords):
            if p["name"] not in hit:
                hit.append(p["name"])
    return hit


def warnings_status():
    def live():
        items = base.parse_data_go_kr_json(base.http_get(WARN + "/getPwnStatus", {
            "serviceKey": config.DATA_GO_KR_KEY, "pageNo": 1, "numOfRows": 10, "dataType": "JSON"}))
        return {"parsed": parse_pwn_status(items), "raw_t6": (items[0].get("t6") if items else "")}

    return base.call("kma_warn", "pwn", 300, live, lambda: {"parsed": [], "raw_t6": "(mock) 발효 중 특보 없음"},
                     bool(config.DATA_GO_KR_KEY))


def warnings_for(station):
    st = warnings_status()
    return {"warnings": match_warnings(st.get("parsed", []), station.get("warn_areas", [])), "_meta": st.get("_meta")}
