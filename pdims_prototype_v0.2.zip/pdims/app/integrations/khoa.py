"""국립해양조사원 조석예보(고·저조, 시계열)·조위관측(실측·예측) — 공공데이터포털 제공분.
응답 필드명이 서비스별로 달라 후보 필드명 목록으로 유연하게 해석한다. (tools/check_apis.py 로 실응답 확인)"""
import math
import re
from datetime import datetime, timedelta
from app import config
from app.integrations import base

ENDPOINTS = {
    "hilo": "http://apis.data.go.kr/1192136/tideFcstHghLw/GetTideFcstHghLwApiService",
    "series": "http://apis.data.go.kr/1192136/tideFcstTime/GetTideFcstTimeApiService",
    "observed": "http://apis.data.go.kr/1192136/surveyTideLevel/GetSurveyTideLevelApiService",
}
TIME_KEYS = ["predcDt", "obsrvnDt", "tph_time", "record_time", "obsTime", "predcTm", "dt"]
LEVEL_KEYS = ["predcTdlvVl", "tph_level", "tide_level", "bscTdlvHgt", "tdlvHgt", "obsTdlv", "tdlv"]
PRED_KEYS = ["predcTdlvVl", "predTdlv", "pred_level"]
TYPE_KEYS = ["extrSe", "hl_code", "tdlvSe", "hlCode"]


def _pick(d, keys, pattern=None):
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    if pattern:
        for k, v in d.items():
            if re.search(pattern, k, re.I) and v not in (None, ""):
                return v
    return None


def _ts(v):
    s = str(v).strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y%m%d%H%M%S", "%Y%m%d%H%M"):
        try:
            return datetime.strptime(s[:len(datetime.now().strftime(fmt))], fmt)
        except Exception:
            continue
    return None


def _type(v, idx_level=None):
    s = str(v or "")
    if "고" in s or s.upper() in ("HIGH", "H") or s in ("1", "3"):
        return "고조"
    if "저" in s or s.upper() in ("LOW", "L") or s in ("2", "4"):
        return "저조"
    return None


def parse_hilo(items):
    ev = []
    for it in items:
        t = _ts(_pick(it, TIME_KEYS, r"(dt|time|tm)$"))
        lv = _pick(it, LEVEL_KEYS, r"(tdlv|level|hgt)")
        if not t:
            continue
        ev.append({"time": t.isoformat(timespec="minutes"), "level_cm": float(lv) if lv not in (None, "") else None,
                   "type": _type(_pick(it, TYPE_KEYS, r"(extr|hl|se)$"))})
    ev.sort(key=lambda e: e["time"])
    # 유형 코드가 없으면 인접값 비교로 고·저조 판정
    for i, e in enumerate(ev):
        if e["type"] is None and e["level_cm"] is not None:
            nb = [x["level_cm"] for x in (ev[i - 1:i] + ev[i + 1:i + 2]) if x["level_cm"] is not None]
            e["type"] = "고조" if nb and e["level_cm"] > max(nb) else "저조"
    return ev


def parse_series(items):
    out = []
    for it in items:
        t = _ts(_pick(it, TIME_KEYS, r"(dt|time|tm)$"))
        if not t:
            continue
        lv = _pick(it, LEVEL_KEYS, r"(tdlv|level|hgt)")
        pr = _pick(it, PRED_KEYS)
        out.append({"time": t.isoformat(timespec="minutes"),
                    "level_cm": float(lv) if lv not in (None, "") else None,
                    "pred_cm": float(pr) if pr not in (None, "") else None})
    out.sort(key=lambda r: r["time"])
    return out


def _req(kind, obs_code, date, extra=None):
    p = {"serviceKey": config.DATA_GO_KR_KEY, "type": "json", "obsCode": obs_code, "reqDate": date,
         "pageNo": 1, "numOfRows": 300}
    p.update(extra or {})
    return base.parse_data_go_kr_json(base.http_get(ENDPOINTS[kind], p))


# ---------- mock: M2+S2 조화 근사 ----------
def _mock_level(t):
    h = t.timestamp() / 3600
    return 350 + 280 * math.cos(2 * math.pi * h / 12.42) + 60 * math.cos(2 * math.pi * h / 12.0)


def mock_hilo(date):
    d0 = datetime.strptime(date, "%Y%m%d")
    ev, prev, pprev = [], None, None
    for m in range(0, 26 * 60, 6):
        t = d0 + timedelta(minutes=m)
        v = _mock_level(t)
        if prev is not None and pprev is not None:
            if prev[1] > pprev and prev[1] > v:
                ev.append({"time": prev[0].isoformat(timespec="minutes"), "level_cm": round(prev[1]), "type": "고조"})
            if prev[1] < pprev and prev[1] < v:
                ev.append({"time": prev[0].isoformat(timespec="minutes"), "level_cm": round(prev[1]), "type": "저조"})
        pprev = prev[1] if prev else None
        prev = (t, v)
    return [e for e in ev if e["time"][:10] == d0.date().isoformat()]


def mock_series(date, step=60):
    d0 = datetime.strptime(date, "%Y%m%d")
    return [{"time": (d0 + timedelta(minutes=m)).isoformat(timespec="minutes"),
             "level_cm": round(_mock_level(d0 + timedelta(minutes=m))), "pred_cm": round(_mock_level(d0 + timedelta(minutes=m)))}
            for m in range(0, 24 * 60, step)]


def tide(obs_code, date=None, days=1):
    date = date or datetime.now().strftime("%Y%m%d")
    enabled = bool(config.DATA_GO_KR_KEY and obs_code)

    def live():
        ev = []
        d0 = datetime.strptime(date, "%Y%m%d")
        for i in range(days):
            ev += parse_hilo(_req("hilo", obs_code, (d0 + timedelta(days=i)).strftime("%Y%m%d")))
        if not ev:
            raise base.ApiError("고·저조 item 없음 (obsCode 확인)")
        return {"obs_code": obs_code, "events": ev}

    def mock():
        d0 = datetime.strptime(date, "%Y%m%d")
        ev = []
        for i in range(days):
            ev += mock_hilo((d0 + timedelta(days=i)).strftime("%Y%m%d"))
        return {"obs_code": obs_code, "events": ev}

    return base.call("khoa_hilo", f"hilo:{obs_code}:{date}:{days}", 6 * 3600, live, mock, enabled)


def series(obs_code, date=None, observed=False):
    date = date or datetime.now().strftime("%Y%m%d")
    kind = "observed" if observed else "series"

    def live():
        rows = parse_series(_req(kind, obs_code, date, {"min": 60} if not observed else {"min": 10}))
        if not rows:
            raise base.ApiError("조위 item 없음")
        return {"obs_code": obs_code, "rows": rows}

    return base.call("khoa_" + kind, f"{kind}:{obs_code}:{date}", 1800 if observed else 6 * 3600, live,
                     lambda: {"obs_code": obs_code, "rows": mock_series(date)}, bool(config.DATA_GO_KR_KEY and obs_code))
