"""연계 사이트·서비스 목록과 현재 상태 (화면 '연계' 탭, 총괄관리자 연계 관리)."""
from app import config
from app.integrations import base

SERVICES = [
    # site, service id, 명칭, 활용 기능, 연계 방식
    ("공공데이터포털", "kma_ncst", "기상청 단기예보 조회서비스 - 초단기실황", "FR-01 판정, FR-03 기상 요약", "REST/JSON, DATA_GO_KR_KEY"),
    ("공공데이터포털", "kma_fcst", "기상청 단기예보 조회서비스 - 초단기·단기예보(파고 WAV 포함)", "FR-09 일정 추천", "REST/JSON, DATA_GO_KR_KEY"),
    ("공공데이터포털", "kma_warn", "기상청 기상특보 조회서비스 - 특보현황(getPwnStatus)", "FR-01 특보 판정", "REST/JSON, DATA_GO_KR_KEY"),
    ("공공데이터포털", "khoa_hilo", "국립해양조사원 조석예보(고·저조)", "FR-03 물때, FR-09 밀물 가중", "REST/JSON, DATA_GO_KR_KEY"),
    ("공공데이터포털", "khoa_series", "국립해양조사원 조석예보(시계열)", "조위 그래프", "REST/JSON, DATA_GO_KR_KEY"),
    ("공공데이터포털", "khoa_observed", "국립해양조사원 조위관측소 실측 조위", "실측·예측 비교", "REST/JSON, DATA_GO_KR_KEY"),
    ("공공데이터포털", "kasi_riseset", "한국천문연구원 출몰시각 정보", "FR-01 주야간 판정", "REST/XML, DATA_GO_KR_KEY"),
    ("공공데이터포털", "file_hazard", "해양경찰청 연안위험구역현황 (파일데이터 SHP)", "위험구역 레이어, FR-07", "파일 → tools/import_hazard_shp.py"),
    ("공공데이터포털", "file_station", "해양경찰청 관서현황 (파일데이터 CSV)", "파출소 위치, FR-21", "파일 → tools/import_stations.py (+브이월드 지오코더)"),
    ("브이월드", "vworld_wmts", "배경·위성·하이브리드 지도 (WMTS)", "FR-02 GIS 배경지도", "WMTS, VWORLD_API_KEY"),
    ("브이월드", "vworld_admin", "행정경계 시도·시군구·읍면동 (2D 데이터 API)", "행정경계 레이어", "REST/JSON(GeoJSON), VWORLD_API_KEY"),
    ("브이월드", "vworld_airspace", "항공·공역 레이어 (비행금지·제한·위험·관제권 등)", "공역 레이어, 경로 지오펜스 검증", "REST/JSON(GeoJSON), VWORLD_API_KEY"),
    ("브이월드", "vworld_geocoder", "주소·좌표 검색 (지오코더)", "주소 검색, 관서 좌표화", "REST/JSON, VWORLD_API_KEY"),
    ("브이월드", "vworld_search", "통합 검색 (장소·주소)", "지도 검색창", "REST/JSON, VWORLD_API_KEY"),
]


def status():
    rows = []
    for site, sid, name, use, how in SERVICES:
        s = base.STATUS.get(sid, {})
        if sid.startswith("file_"):
            mode = "file"
        elif sid.startswith("vworld"):
            mode = s.get("mode") or ("ready" if config.VWORLD_API_KEY else "mock")
        else:
            mode = s.get("mode") or ("ready" if config.DATA_GO_KR_KEY else "mock")
        if config.FORCE_MOCK and not sid.startswith("file_"):
            mode = "mock"
        rows.append({"site": site, "id": sid, "name": name, "use": use, "how": how, "mode": mode,
                     "calls": s.get("calls", 0), "ok": s.get("ok", 0), "fail": s.get("fail", 0),
                     "avg_ms": s.get("avg_ms", 0), "last_ok": s.get("last_ok"), "last_error": s.get("last_error")})
    return {"keys": {"DATA_GO_KR_KEY": base.mask(config.DATA_GO_KR_KEY),
                     "VWORLD_API_KEY": base.mask(config.VWORLD_API_KEY),
                     "VWORLD_DOMAIN": config.VWORLD_DOMAIN, "VWORLD_TILE_MODE": config.VWORLD_TILE_MODE,
                     "FORCE_MOCK": config.FORCE_MOCK},
            "services": rows}
