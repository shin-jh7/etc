"""한국천문연구원 출몰시각 정보 (공공데이터포털, XML 응답). 실패 시 NOAA 근사식."""
import xml.etree.ElementTree as ET
from datetime import datetime, date as _date
from app import config
from app.core import sun
from app.integrations import base

URL = "http://apis.data.go.kr/B090041/openapi/service/RiseSetInfoService/getLCRiseSetInfo"


def _hm(s):
    s = (s or "").strip()
    return f"{s[:2]}:{s[2:4]}" if len(s) >= 4 and s[:4].isdigit() else None


def parse_xml(text):
    root = ET.fromstring(text.encode("utf-8") if isinstance(text, str) else text)
    code = root.findtext(".//resultCode")
    if code and code not in ("00", "0"):
        raise base.ApiError(f"천문연 결과코드 {code}: {root.findtext('.//resultMsg')}")
    err = root.findtext(".//returnAuthMsg")
    if err:
        raise base.ApiError("천문연 인증 오류: " + err)
    it = root.find(".//item")
    if it is None:
        raise base.ApiError("출몰시각 item 없음")
    return {"sunrise": _hm(it.findtext("sunrise")), "sunset": _hm(it.findtext("sunset")),
            "civil_dawn": _hm(it.findtext("civilm")), "civil_dusk": _hm(it.findtext("civile"))}


def sun_info(lat, lon, d: _date = None):
    d = d or datetime.now().date()

    def live():
        text = base.http_get(URL, {"serviceKey": config.DATA_GO_KR_KEY, "locdate": d.strftime("%Y%m%d"),
                                   "longitude": round(lon, 4), "latitude": round(lat, 4), "dnYn": "Y"})
        return {"date": d.isoformat(), **parse_xml(text)}

    return base.call("kasi_riseset", f"sun:{round(lat,2)}:{round(lon,2)}:{d}", 24 * 3600, live,
                     lambda: sun.sun_times(d, lat, lon), bool(config.DATA_GO_KR_KEY))
