"""PDIMS 순찰드론 종합관리시스템 프로토타입 v0.2 — FastAPI 서버."""
import asyncio
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect, Body
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles

from app import config, services, store
from app.core import jurisdiction
from app.core.simulator import SimManager
from app.integrations import kma, khoa, astro, vworld, registry

SIM = SimManager()


@asynccontextmanager
async def lifespan(app):
    SIM.task = asyncio.create_task(SIM.loop())
    yield
    SIM.task.cancel()


app = FastAPI(title="PDIMS 순찰드론 종합관리시스템 (프로토타입 v0.2)", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(config.STATIC_DIR)), name="static")


def _run(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except KeyError as e:
        raise HTTPException(404, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/")
def index():
    return FileResponse(str(config.STATIC_DIR / "index.html"))


@app.get("/api/config")
def get_config():
    return {"default_station": config.DEFAULT_STATION, "tile_mode": config.VWORLD_TILE_MODE,
            "vworld_enabled": vworld.enabled(),
            "vworld_key": config.VWORLD_API_KEY if config.VWORLD_TILE_MODE == "direct" else None,
            "force_mock": config.FORCE_MOCK, "version": "0.2.0"}


# ---------- 기준 정보 ----------
@app.get("/api/stations")
def get_stations():
    return services.stations()


@app.get("/api/jurisdictions")
def get_jurisdictions():
    return jurisdiction.load()


@app.get("/api/jurisdictions/lookup")
def lookup(lat: float, lon: float):
    return jurisdiction.lookup(lat, lon)


@app.get("/api/hazards")
def hazards():
    return store.read("hazard_zones.geojson")


@app.get("/api/routes")
def get_routes():
    return store.read("routes.json", [])


@app.get("/api/drones")
def get_drones():
    return services.drones()


@app.post("/api/drones")
def post_drone(d: dict = Body(...)):
    if not d.get("name"):
        raise HTTPException(400, "name 필수")
    return services.add_drone(d)


@app.delete("/api/drones/{did}")
def del_drone(did: str):
    return services.delete_drone(did)


# ---------- 기상·판정 ----------
@app.get("/api/conditions")
def conditions(station: str):
    return _run(services.conditions, station)


@app.get("/api/judge")
def judge(station: str, drone: str):
    return _run(services.judge_now, station, drone)


@app.get("/api/schedule")
def schedule(station: str, drone: str, hours: int = 72, duration: int = 1, mission: str = "patrol"):
    return _run(services.schedule_rec, station, drone, min(hours, 72), duration, mission)


@app.get("/api/tide")
def tide(station: str, date: str = None):
    st = _run(services.station, station)
    return {"hilo": khoa.tide(st.get("obs_code"), date), "series": khoa.series(st.get("obs_code"), date)}


@app.get("/api/tide/observed")
def tide_observed(station: str, date: str = None):
    st = _run(services.station, station)
    return khoa.series(st.get("obs_code"), date, observed=True)


@app.get("/api/warnings")
def warnings_raw():
    return kma.warnings_status()


# ---------- 임무·관제 ----------
@app.post("/api/mission/plan")
def plan(req: dict = Body(...)):
    return _run(services.plan_mission, req)


@app.post("/api/sim/start")
def sim_start(plan: dict = Body(...)):
    st = _run(services.station, plan["station"])
    d = _run(services.drone, plan["drone"])
    m = SIM.create(plan=plan, drone=d, station=st, wind=plan.get("wind") or 0,
                   wind_dir=plan.get("wind_dir") or 0, time_scale=float(plan.get("time_scale", 5)))
    m.command("takeoff")
    return m.snapshot()


@app.post("/api/sim/{mid}/cmd")
def sim_cmd(mid: str, cmd: str):
    m = SIM.missions.get(mid)
    if not m:
        raise HTTPException(404, "mission 없음")
    if not m.command(cmd):
        raise HTTPException(400, f"현재 상태({m.state})에서 수행할 수 없는 명령: {cmd}")
    return m.snapshot()


@app.get("/api/sim")
def sim_list():
    return [m.snapshot() for m in SIM.missions.values()]


@app.delete("/api/sim/{mid}")
def sim_del(mid: str):
    SIM.missions.pop(mid, None)
    return {"deleted": mid}


@app.websocket("/ws/telemetry")
async def ws_telemetry(ws: WebSocket):
    await ws.accept()
    q = asyncio.Queue(maxsize=20)
    SIM.subscribers.add(q)
    try:
        while True:
            snaps = await q.get()
            await ws.send_json(snaps)
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        SIM.subscribers.discard(q)


# ---------- 브이월드 ----------
@app.get("/api/vworld/tile/{layer}/{z}/{y}/{x}")
def vw_tile(layer: str, z: int, y: int, x: int):
    if not vworld.enabled():
        raise HTTPException(503, "VWORLD_API_KEY 미설정")
    try:
        body, ctype = vworld.tile(layer, z, y, x)
    except Exception as e:
        raise HTTPException(502, str(e))
    return Response(content=body, media_type=ctype, headers={"Cache-Control": "public, max-age=86400"})


def _bbox(s):
    v = [float(x) for x in s.split(",")]
    if len(v) != 4:
        raise HTTPException(400, "bbox=minLon,minLat,maxLon,maxLat")
    return v


@app.get("/api/admin-boundary")
def admin_boundary(bbox: str, level: str = "sigungu"):
    if level not in vworld.ADMIN_LAYERS:
        raise HTTPException(400, "level: sido/sigungu/emd")
    return vworld.admin_boundary(level, _bbox(bbox))


@app.get("/api/airspace")
def airspace(bbox: str):
    return vworld.airspace(_bbox(bbox))


@app.get("/api/geocode")
def geocode(q: str):
    return vworld.geocode(q)


@app.get("/api/revgeocode")
def revgeocode(lat: float, lon: float):
    return vworld.reverse(lat, lon)


@app.get("/api/search")
def search(q: str, kind: str = "place"):
    return vworld.search(q, kind)


# ---------- 연계 관리 ----------
@app.get("/api/integrations")
def integrations():
    return registry.status()


@app.get("/api/health")
def health():
    return {"ok": True, "time": datetime.now().isoformat(timespec="seconds")}
