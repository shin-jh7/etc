"""6.2 최적 운항 일정 추천."""
from datetime import datetime, timedelta
from app.core.judge import judge, score, NO_GO
from app.core import sun


def tide_bonus(ts: datetime, tide_events, mission):
    """위험구역(갯벌) 순찰: 저조 이후 밀물 시작 1~2시간 전 가중."""
    if mission != "hazard" or not tide_events:
        return 0
    for ev in tide_events:
        if ev.get("type") != "저조":
            continue
        try:
            t = datetime.fromisoformat(ev["time"])
        except Exception:
            continue
        diff = (t - ts).total_seconds() / 3600
        if 1 <= diff <= 2:
            return 10
        if 0 <= diff < 1:
            return 5
    return 0


def recommend(hourly, drone, warnings, station, tide_events=None, duration_h=1, mission="patrol", top=3):
    rows = []
    for h in hourly:
        ts = datetime.fromisoformat(h["time"])
        st = sun.sun_times(ts.date(), station["lat"], station["lon"])
        night = sun.is_night(ts, st)
        j = judge(h, drone, warnings=warnings if (ts - datetime.fromisoformat(hourly[0]["time"])).total_seconds() < 6 * 3600 else None,
                  night=night, ship_based=station.get("type") == "ship")
        sc = score(j)
        if j["result"] != NO_GO:
            sc = min(100, sc + tide_bonus(ts, tide_events, mission))
        rows.append({"time": h["time"], "result": j["result"], "score": sc, "night": night,
                     "reasons": j["reasons"][:3], "wind": h.get("wind"), "wave": h.get("wave"), "precip": h.get("precip")})
    windows = []
    n = max(1, int(duration_h))
    for i in range(len(rows) - n + 1):
        seg = rows[i:i + n]
        if any(r["result"] == NO_GO for r in seg):
            continue
        windows.append({"start": seg[0]["time"],
                        "end": (datetime.fromisoformat(seg[-1]["time"]) + timedelta(hours=1)).isoformat(timespec="minutes"),
                        "score": round(sum(r["score"] for r in seg) / n),
                        "result": "CAUTION" if any(r["result"] == "CAUTION" for r in seg) else "GO"})
    windows.sort(key=lambda w: (-w["score"], w["start"]))
    picked = []
    for wdw in windows:
        if all(abs((datetime.fromisoformat(wdw["start"]) - datetime.fromisoformat(p["start"])).total_seconds()) >= 3 * 3600 for p in picked):
            picked.append(wdw)
        if len(picked) >= top:
            break
    return {"hours": rows, "top": picked}
