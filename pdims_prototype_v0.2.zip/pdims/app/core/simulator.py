"""FR-11 / 9장 드론 시뮬레이터: 텔레메트리, 배터리 경고·자동 귀환, 통신 두절 귀환, 위험 감지 이벤트."""
import asyncio
import itertools
import math
import random
import time
from app import geo

_ids = itertools.count(1)
EVENT_TYPES = ["익수자 의심", "소형 선박", "갯벌 고립자 의심", "연기·화재 의심"]


class Mission:
    def __init__(self, plan, drone, station, wind=0.0, wind_dir=0.0, time_scale=5.0, event_rate=0.004):
        self.id = f"M{next(_ids):04d}"
        self.plan = plan
        self.drone = drone
        self.station = station
        self.wps = [tuple(p) for p in plan["waypoints"]]
        self.hover_s = plan.get("hover_s", 0)
        self.hover_idx = set(plan.get("hover_points", []))
        self.alt_target = plan.get("alt_m", 100)
        spec = drone.get("spec", {})
        self.cruise = spec.get("cruise_speed", 12.0)
        self.endurance = spec.get("endurance_min", 35) * 60
        self.comm = spec.get("comm_range_m", 7000)
        self.wind, self.wind_dir = wind or 0.0, wind_dir or 0.0
        self.scale = time_scale
        self.event_rate = event_rate
        self.lat, self.lon = station["lat"], station["lon"]
        self.alt, self.batt, self.t = 0.0, 100.0, 0.0
        self.state = "READY"   # READY TAKEOFF ENROUTE HOVER RTL LANDING LANDED PAUSED MANUAL
        self.prev_state = None
        self.idx, self.hover_left = 0, 0
        self.track, self.events, self.alerts = [], [], []
        self.warned = set()
        self.dist = 0.0
        self.link = True

    # ----- 명령 -----
    def command(self, cmd):
        if cmd == "takeoff" and self.state == "READY":
            self.state = "TAKEOFF"
        elif cmd == "pause" and self.state in ("TAKEOFF", "ENROUTE", "HOVER", "RTL", "MANUAL"):
            self.prev_state, self.state = self.state, "PAUSED"
        elif cmd == "resume" and self.state in ("PAUSED", "MANUAL"):
            self.state = self.prev_state or "ENROUTE"
        elif cmd == "rtl" and self.state not in ("LANDED", "LANDING", "READY"):
            self._rtl("운용자 귀환 명령")
        elif cmd == "manual" and self.state not in ("LANDED", "READY"):
            self.prev_state, self.state = self.state, "MANUAL"
        elif cmd.startswith("speed:"):
            self.scale = max(1.0, min(60.0, float(cmd.split(":")[1])))
        else:
            return False
        self._alert("INFO", f"명령 수행: {cmd}")
        return True

    def _alert(self, level, msg):
        self.alerts.append({"t": round(self.t), "level": level, "msg": msg, "at": time.strftime("%H:%M:%S")})
        self.alerts = self.alerts[-50:]

    def _rtl(self, why):
        if self.state != "RTL":
            self.state = "RTL"
            self._alert("WARN", f"자동/수동 귀환: {why}")

    # ----- 이동 -----
    def _ground_speed(self, brg):
        # 순풍(+)/역풍(-) 성분 반영. wind_dir 는 '불어오는' 방향
        head = self.wind * math.cos(math.radians(brg - ((self.wind_dir + 180) % 360)))
        return max(2.0, self.cruise + head)

    def _move_to(self, tgt, dt):
        d = geo.haversine(self.lat, self.lon, *tgt)
        brg = geo.bearing(self.lat, self.lon, *tgt)
        step = self._ground_speed(brg) * dt
        if step >= d:
            self.lat, self.lon = tgt
            self.dist += d
            return True, brg
        self.lat, self.lon = geo.destination(self.lat, self.lon, brg, step)
        self.dist += step
        return False, brg

    def step(self, dt):
        if self.state in ("READY", "LANDED", "PAUSED"):
            return self.snapshot()
        self.t += dt
        drain = 100.0 / self.endurance * dt * (1 + 0.02 * self.wind)
        if self.state != "MANUAL":
            self.batt = max(0.0, self.batt - drain)
        brg = 0.0
        if self.state == "TAKEOFF":
            self.alt = min(self.alt_target, self.alt + 4 * dt)
            if self.alt >= self.alt_target:
                self.state = "ENROUTE"
                self._alert("INFO", "이륙 완료, 경로 비행 시작")
        elif self.state == "ENROUTE":
            if self.idx >= len(self.wps):
                self._rtl("임무 완료")
            else:
                arrived, brg = self._move_to(self.wps[self.idx], dt)
                if arrived:
                    if self.idx in self.hover_idx and self.hover_s:
                        self.state, self.hover_left = "HOVER", self.hover_s
                    self.idx += 1
        elif self.state == "HOVER":
            self.hover_left -= dt
            if self.hover_left <= 0:
                self.state = "ENROUTE"
        elif self.state == "RTL":
            arrived, brg = self._move_to((self.station["lat"], self.station["lon"]), dt)
            if arrived:
                self.state = "LANDING"
        elif self.state == "LANDING":
            self.alt = max(0.0, self.alt - 3 * dt)
            if self.alt <= 0:
                self.state = "LANDED"
                self._alert("INFO", f"착륙 완료 (비행 {round(self.t)}초, {round(self.dist)}m, 잔량 {round(self.batt,1)}%)")
        # 배터리 경고·자동 귀환
        for th, lvl in ((30, "WARN"), (20, "WARN")):
            if self.batt <= th and th not in self.warned:
                self.warned.add(th)
                self._alert(lvl, f"배터리 {th}% 이하")
        if self.batt <= 15 and self.state in ("ENROUTE", "HOVER", "MANUAL"):
            self._rtl("배터리 15% 이하")
        # 통신 두절
        far = geo.haversine(self.lat, self.lon, self.station["lat"], self.station["lon"])
        link = far <= self.comm
        if not link and self.link:
            self._alert("ALERT", f"통신 두절 ({far/1000:.1f}km) → 자동 귀환")
            self._rtl("통신 두절")
        self.link = link
        # 위험 감지 이벤트 (시뮬레이션)
        if self.state in ("ENROUTE", "HOVER") and random.random() < self.event_rate * dt:
            ev = {"id": f"E{len(self.events)+1:03d}", "type": random.choice(EVENT_TYPES),
                  "lat": round(self.lat, 6), "lon": round(self.lon, 6), "t": round(self.t),
                  "confidence": round(random.uniform(0.6, 0.97), 2),
                  "bbox": [random.randint(100, 900), random.randint(80, 500), random.randint(40, 160), random.randint(40, 160)],
                  "at": time.strftime("%H:%M:%S")}
            self.events.append(ev)
            self._alert("ALERT", f'위험 감지: {ev["type"]} (신뢰도 {ev["confidence"]}) → 상황실 영상 자동 전송(모의)')
        self.track.append([round(self.lat, 6), round(self.lon, 6)])
        self.track = self.track[-2000:]
        return self.snapshot(brg)

    def snapshot(self, heading=0.0):
        return {"mission": self.id, "state": self.state, "lat": round(self.lat, 6), "lon": round(self.lon, 6),
                "alt": round(self.alt, 1), "battery": round(self.batt, 1), "t": round(self.t),
                "speed": round(self.cruise, 1), "heading": round(heading), "wp": self.idx, "wp_total": len(self.wps),
                "dist": round(self.dist), "link": self.link, "scale": self.scale,
                "events": self.events[-10:], "alerts": self.alerts[-10:], "drone": self.drone.get("name")}


class SimManager:
    def __init__(self):
        self.missions = {}
        self.subscribers = set()
        self.task = None

    def create(self, **kw):
        m = Mission(**kw)
        self.missions[m.id] = m
        return m

    async def loop(self, tick=0.5):
        while True:
            await asyncio.sleep(tick)
            snaps = []
            for m in list(self.missions.values()):
                snaps.append(m.step(tick * m.scale))
            if snaps and self.subscribers:
                dead = []
                for q in self.subscribers:
                    try:
                        q.put_nowait(snaps)
                    except Exception:
                        dead.append(q)
                for q in dead:
                    self.subscribers.discard(q)

    def run_offline(self, mid, max_s=7200, dt=1.0):
        """테스트용: 착륙까지 동기 실행."""
        m = self.missions[mid]
        m.command("takeoff")
        while m.state != "LANDED" and m.t < max_s:
            m.step(dt)
        return m
