"""일출·일몰·시민박명 오프라인 계산 (NOAA 근사식). 천문연 API 장애 시 대체값."""
import math
from datetime import date, datetime, timedelta, timezone

KST = timezone(timedelta(hours=9))


def _event(d: date, lat, lon, zenith, rising):
    N = d.timetuple().tm_yday
    lng_hour = lon / 15.0
    t = N + ((6 - lng_hour) / 24 if rising else (18 - lng_hour) / 24)
    M = 0.9856 * t - 3.289
    L = (M + 1.916 * math.sin(math.radians(M)) + 0.020 * math.sin(math.radians(2 * M)) + 282.634) % 360
    RA = math.degrees(math.atan(0.91764 * math.tan(math.radians(L)))) % 360
    RA = (RA + (math.floor(L / 90) * 90 - math.floor(RA / 90) * 90)) / 15
    sin_dec = 0.39782 * math.sin(math.radians(L))
    cos_dec = math.cos(math.asin(sin_dec))
    cos_h = (math.cos(math.radians(zenith)) - sin_dec * math.sin(math.radians(lat))) / (cos_dec * math.cos(math.radians(lat)))
    if cos_h > 1 or cos_h < -1:
        return None
    H = (360 - math.degrees(math.acos(cos_h))) if rising else math.degrees(math.acos(cos_h))
    H /= 15
    T = H + RA - 0.06571 * t - 6.622
    UT = (T - lng_hour) % 24
    base = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    return (base + timedelta(hours=UT)).astimezone(KST)


def sun_times(d: date, lat, lon):
    def hm(x):
        return x.strftime("%H:%M") if x else None
    return {
        "date": d.isoformat(),
        "sunrise": hm(_event(d, lat, lon, 90.833, True)),
        "sunset": hm(_event(d, lat, lon, 90.833, False)),
        "civil_dawn": hm(_event(d, lat, lon, 96.0, True)),
        "civil_dusk": hm(_event(d, lat, lon, 96.0, False)),
    }


def is_night(dt: datetime, st: dict):
    """시민박명 이전/이후면 야간."""
    if not st.get("civil_dawn") or not st.get("civil_dusk"):
        return False
    hm = dt.strftime("%H:%M")
    return hm < st["civil_dawn"] or hm > st["civil_dusk"]
