"""FR-06/07/08 임무 경로: 표준경로 검증, 위험구역 순찰(TSP), 해상 수색 패턴."""
import math
from app import geo


def estimate(points, drone, hover_s=0, wind=0.0):
    """points: [(lat,lon)]. 반환: 거리, 비행시간, 배터리 사용률."""
    spec = drone.get("spec", {})
    cruise = spec.get("cruise_speed", 12.0)
    endurance_min = spec.get("endurance_min", 35)
    dist = geo.path_length(points)
    eff_speed = max(3.0, cruise - 0.35 * (wind or 0))  # 맞바람 보정(보수)
    t = dist / eff_speed + hover_s + 60  # 이착륙 60초
    batt = t / (endurance_min * 60) * 100
    return {"distance_m": round(dist), "flight_s": round(t), "battery_pct": round(batt, 1)}


def validate(points, drone, station, alt_m=100, wind=0.0, hover_s=0, jurisdiction_check=None, airspace=None):
    spec = drone.get("spec", {})
    est = estimate(points, drone, hover_s, wind)
    reserve = spec.get("reserve_pct", 25)
    issues = []
    if est["battery_pct"] > 100 - reserve:
        issues.append({"level": "NO_GO", "type": "배터리", "msg": f'예상 소모 {est["battery_pct"]}% > 가용 {100-reserve}% (예비 {reserve}%)'})
    elif est["battery_pct"] > (100 - reserve) * 0.8:
        issues.append({"level": "CAUTION", "type": "배터리", "msg": f'예상 소모 {est["battery_pct"]}% (가용치 80% 초과)'})
    if alt_m > 150:
        issues.append({"level": "NO_GO", "type": "고도", "msg": f"고도 {alt_m}m > 150m (항공안전법 기준, 승인 필요)"})
    rng = spec.get("comm_range_m", 7000)
    far = max(geo.haversine(station["lat"], station["lon"], p[0], p[1]) for p in points)
    if far > rng:
        issues.append({"level": "NO_GO", "type": "통신거리", "msg": f"최대 이격 {far/1000:.1f}km > 통신 {rng/1000:.1f}km"})
    elif far > rng * 0.8:
        issues.append({"level": "CAUTION", "type": "통신거리", "msg": f"최대 이격 {far/1000:.1f}km (통신 한계 80% 초과)"})
    if jurisdiction_check:
        out = jurisdiction_check(points)
        if out:
            issues.append({"level": "CAUTION", "type": "관할", "msg": f"관할구역 이탈 지점 {len(out)}곳 (인접 파출소 협조 필요)", "points": out})
    if airspace:
        hits = airspace_hits(points, airspace)
        for h in hits:
            lvl = "NO_GO" if h["kind"] in ("비행금지구역",) else "CAUTION"
            issues.append({"level": lvl, "type": "공역", "msg": f'{h["kind"]} "{h["name"]}" 통과 (승인 필요)'})
    overall = "NO_GO" if any(i["level"] == "NO_GO" for i in issues) else ("CAUTION" if issues else "GO")
    return {"result": overall, "estimate": est, "issues": issues, "max_distance_m": round(far)}


def airspace_hits(points, airspace_fc):
    hits, seen = [], set()
    feats = (airspace_fc or {}).get("features", [])
    for f in feats:
        g = f.get("geometry")
        if not g:
            continue
        for i in range(len(points) - 1):
            a = (points[i][1], points[i][0])
            b = (points[i + 1][1], points[i + 1][0])
            if geo.segment_hits_geometry(a, b, g):
                pr = f.get("properties", {})
                key = (pr.get("_kind"), pr.get("_name"))
                if key not in seen:
                    seen.add(key)
                    hits.append({"kind": pr.get("_kind", "공역"), "name": pr.get("_name", "-")})
                break
    return hits


# ---------- 위험구역 순찰: TSP (최근접 이웃 + 2-opt) ----------
def tsp_route(base, pts):
    """base: (lat,lon), pts: [(lat,lon)] → 방문 순서 index 목록 (기지 출발·복귀)."""
    if not pts:
        return []
    nodes = [base] + list(pts)
    D = [[geo.haversine(*a, *b) for b in nodes] for a in nodes]
    order, left, cur = [0], set(range(1, len(nodes))), 0
    while left:
        nxt = min(left, key=lambda j: D[cur][j])
        order.append(nxt)
        left.remove(nxt)
        cur = nxt
    order.append(0)
    improved = True
    while improved:
        improved = False
        for i in range(1, len(order) - 2):
            for k in range(i + 1, len(order) - 1):
                a, b, c, d = order[i - 1], order[i], order[k], order[k + 1]
                if D[a][c] + D[b][d] < D[a][b] + D[c][d] - 1e-6:
                    order[i:k + 1] = reversed(order[i:k + 1])
                    improved = True
    return [i - 1 for i in order[1:-1]]


# ---------- 해상 수색 패턴 (IAMSAR) ----------
def expanding_square(lat, lon, spacing, legs, start_brg=0):
    pts, cur, brg = [(lat, lon)], (lat, lon), start_brg
    for i in range(legs):
        L = spacing * (i // 2 + 1)
        cur = geo.destination(cur[0], cur[1], brg, L)
        pts.append(cur)
        brg = (brg + 90) % 360
    return pts


def sector_search(lat, lon, radius, start_brg=0):
    pts, b = [(lat, lon)], start_brg
    for _ in range(3):
        pts.append(geo.destination(lat, lon, b, radius))
        pts.append(geo.destination(lat, lon, (b + 120) % 360, radius))
        pts.append((lat, lon))
        b = (b + 30) % 360  # 다음 삼각형은 30° 회전 (VS 표준)
    return pts


def parallel_track(lat, lon, width, length, spacing, axis_brg=0, creeping=False):
    """PS: 트랙이 축 방향, CS(creeping): 트랙이 축에 수직."""
    track_brg = (axis_brg + 90) % 360 if creeping else axis_brg
    step_brg = axis_brg if creeping else (axis_brg + 90) % 360
    track_len = width if creeping else length
    n = max(1, int((length if creeping else width) / spacing))
    start = geo.destination(lat, lon, (step_brg + 180) % 360, n * spacing / 2)
    start = geo.destination(*start, (track_brg + 180) % 360, track_len / 2)
    pts, cur = [start], start
    for i in range(n + 1):
        b = track_brg if i % 2 == 0 else (track_brg + 180) % 360
        cur = geo.destination(*cur, b, track_len)
        pts.append(cur)
        if i < n:
            cur = geo.destination(*cur, step_brg, spacing)
            pts.append(cur)
    return pts


def search_pattern(kind, lat, lon, spacing=200, legs=12, radius=1000, width=2000, length=2000, brg=0):
    if kind == "SS":
        return expanding_square(lat, lon, spacing, legs, brg)
    if kind == "VS":
        return sector_search(lat, lon, radius, brg)
    if kind == "PS":
        return parallel_track(lat, lon, width, length, spacing, brg, creeping=False)
    if kind == "CS":
        return parallel_track(lat, lon, width, length, spacing, brg, creeping=True)
    raise ValueError("pattern must be SS/VS/PS/CS")
