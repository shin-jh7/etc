"""6.7 파출소 관할구역: 조회·공동관할 판별·이탈 검사."""
import json
from app import config, geo

_cache = {"fc": None, "mtime": 0}


def load():
    p = config.DATA_DIR / "jurisdictions.geojson"
    m = p.stat().st_mtime
    if _cache["fc"] is None or m != _cache["mtime"]:
        _cache["fc"] = json.loads(p.read_text(encoding="utf-8"))
        _cache["mtime"] = m
    return _cache["fc"]


def lookup(lat, lon):
    hits = []
    for f in load()["features"]:
        if geo.point_in_geometry(lon, lat, f["geometry"]):
            pr = f["properties"]
            hits.append({"id": pr["id"], "name": pr["name"], "priority": pr.get("priority", 9),
                         "office": pr.get("office"), "base": pr.get("base")})
    hits.sort(key=lambda h: h["priority"])
    return {"lat": lat, "lon": lon, "count": len(hits), "joint": len(hits) > 1,
            "primary": hits[0] if hits else None, "all": hits,
            "rule": "공동관할: priority 값이 작은 파출소가 주관, 나머지는 협조" if len(hits) > 1 else None}


def outside_points(station_id, points):
    feat = next((f for f in load()["features"] if f["properties"]["id"] == station_id), None)
    if not feat:
        return []
    out = []
    for i, (la, lo) in enumerate(points):
        if not geo.point_in_geometry(lo, la, feat["geometry"]):
            out.append({"index": i, "lat": round(la, 6), "lon": round(lo, 6)})
    return out
