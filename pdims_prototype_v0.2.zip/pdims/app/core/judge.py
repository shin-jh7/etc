"""6.1 운항 가능 판정 엔진: GO / CAUTION / NO_GO."""
from app import config

GO, CAUTION, NO_GO = "GO", "CAUTION", "NO_GO"
RANK = {GO: 0, CAUTION: 1, NO_GO: 2}

# 특보별 운항 정책 (총괄관리자 공통 기준의 기본값)
WARNING_POLICY = {
    "태풍": NO_GO, "강풍경보": NO_GO, "풍랑경보": NO_GO, "호우경보": NO_GO, "대설경보": NO_GO,
    "강풍주의보": CAUTION, "풍랑주의보": CAUTION, "호우주의보": CAUTION, "대설주의보": CAUTION,
    "안개": CAUTION, "폭풍해일": NO_GO, "지진해일": NO_GO,
}


def _warn_level(name: str):
    for k, v in WARNING_POLICY.items():
        if k in name:
            return v
    return CAUTION if "주의보" in name else (NO_GO if "경보" in name else CAUTION)


def _upper(item, value, limit, unit, ratio):
    if value is None:
        return {"item": item, "status": CAUTION, "value": None, "limit": limit, "reason": "데이터 없음(보수 판정)"}
    if limit is None:
        return {"item": item, "status": GO, "value": value, "limit": None, "reason": "한계 미설정"}
    if value > limit:
        return {"item": item, "status": NO_GO, "value": value, "limit": limit, "reason": f"{value}{unit} > 한계 {limit}{unit}"}
    if value > limit * ratio:
        return {"item": item, "status": CAUTION, "value": value, "limit": limit,
                "reason": f"{value}{unit} 는 한계의 {int(ratio*100)}% 초과"}
    return {"item": item, "status": GO, "value": value, "limit": limit, "reason": "정상"}


def judge(wx: dict, drone: dict, warnings=None, night=False, ship_based=False, ratio=None):
    """wx: wind, gust, precip, temp, visibility_km, wave, estimated(list)"""
    ratio = ratio or config.CAUTION_RATIO
    lim = drone.get("limits", {})
    items = [
        _upper("풍속", wx.get("wind"), lim.get("max_wind"), "m/s", ratio),
        _upper("순간풍속", wx.get("gust"), lim.get("max_gust"), "m/s", ratio),
    ]
    # 강수
    p = wx.get("precip")
    if p is None:
        items.append({"item": "강수", "status": CAUTION, "value": None, "reason": "데이터 없음(보수 판정)"})
    elif p > 0 and not lim.get("rain_ok", False):
        items.append({"item": "강수", "status": NO_GO, "value": p, "reason": f"강수 {p}mm/h, 비방수 기종"})
    else:
        items.append(_upper("강수", p, lim.get("max_precip"), "mm/h", ratio))
    # 기온
    t = wx.get("temp")
    if t is None:
        items.append({"item": "기온", "status": CAUTION, "value": None, "reason": "데이터 없음(보수 판정)"})
    else:
        lo, hi = lim.get("min_temp", -10), lim.get("max_temp", 40)
        st = NO_GO if (t < lo or t > hi) else (CAUTION if (t < lo + 3 or t > hi - 3) else GO)
        items.append({"item": "기온", "status": st, "value": t, "limit": [lo, hi],
                      "reason": "정상" if st == GO else f"운용 온도 {lo}~{hi}℃ 경계"})
    # 시정 (하한)
    v, vmin = wx.get("visibility_km"), lim.get("min_visibility_km", 3)
    if v is None:
        items.append({"item": "시정", "status": CAUTION, "value": None, "limit": vmin, "reason": "시정 자료 미연계(보수 판정)"})
    else:
        st = NO_GO if v < vmin else (CAUTION if v < vmin / ratio else GO)
        items.append({"item": "시정", "status": st, "value": v, "limit": vmin, "reason": "정상" if st == GO else f"시정 {v}km"})
    # 파고 (함정 이착륙 시 필수)
    wave_lim = lim.get("max_wave_ship") if ship_based else lim.get("max_wave")
    if ship_based or wx.get("wave") is not None:
        items.append(_upper("파고", wx.get("wave"), wave_lim, "m", ratio))
    # 특보
    if warnings:
        worst = max((_warn_level(w) for w in warnings), key=lambda s: RANK[s])
        items.append({"item": "기상특보", "status": worst, "value": ", ".join(warnings), "reason": "특보 발효"})
    else:
        items.append({"item": "기상특보", "status": GO, "value": "없음", "reason": "정상"})
    # 주야간
    if night:
        st = CAUTION if lim.get("night_ok", False) else NO_GO
        items.append({"item": "주야간", "status": st, "value": "야간",
                      "reason": "야간 운용 가능 기종(주의)" if st == CAUTION else "야간 운용 불가 기종"})
    else:
        items.append({"item": "주야간", "status": GO, "value": "주간", "reason": "정상"})

    est = wx.get("estimated") or []
    for it in items:
        if it["item"] in est and it["status"] == GO:
            it["reason"] += " (추정치)"
    overall = max((i["status"] for i in items), key=lambda s: RANK[s])
    reasons = [f'{i["item"]}: {i["reason"]}' for i in items if i["status"] != GO]
    return {"result": overall, "items": items, "reasons": reasons,
            "low_confidence": bool(wx.get("stale") or est)}


def score(j):
    """판정 결과 → 적합도 점수(0~100)."""
    s = 100
    for it in j["items"]:
        if it["status"] == NO_GO:
            return 0
        if it["status"] == CAUTION:
            s -= 15
        v, l = it.get("value"), it.get("limit")
        if isinstance(v, (int, float)) and isinstance(l, (int, float)) and l:
            s -= max(0, min(15, (v / l) * 10 - 3))
    return max(5, round(s))
