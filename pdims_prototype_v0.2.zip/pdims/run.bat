@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PORT=%1
if "%PORT%"=="" set PORT=8000
set PYTHONUTF8=1

if not exist ".env" (
  echo [안내] .env 파일이 없어 .env.example 을 복사합니다. API 키를 입력하세요.
  copy /Y ".env.example" ".env" >nul
)

where py >nul 2>nul
if %ERRORLEVEL%==0 (set PYBOOT=py -3) else (set PYBOOT=python)

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] 가상환경 생성 중...
  %PYBOOT% -m venv .venv
  if errorlevel 1 ( echo [오류] 가상환경 생성 실패. Python 3.10 이상 설치 여부를 확인하세요. & pause & exit /b 1 )
)
set VPY=.venv\Scripts\python.exe

echo [2/3] 패키지 확인/설치 중...
%VPY% -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 ( echo [오류] 패키지 설치 실패. 프록시/폐쇄망이면 README 5절 참고. & pause & exit /b 1 )

%VPY% -c "import app.main" 
if errorlevel 1 ( echo [오류] 앱 로딩 실패. 위 오류 내용을 알려주세요. & pause & exit /b 1 )

echo [3/3] 서버 시작: http://localhost:%PORT%   (API 문서 /docs, 연계 점검: .venv\Scripts\python tools\check_apis.py)
%VPY% -m uvicorn app.main:app --host 0.0.0.0 --port %PORT% --reload
pause
