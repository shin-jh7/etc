"""연계 어댑터 파서·장애 대체 테스트 (네트워크 불필요): python tests/test_adapters.py"""
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import config  # noqa: E402
from app.integrations import base, kma, khoa, astro, vworld  # noqa: E402
config.FORCE_MOCK = False  # 장애 대체 경로 검증을 위해 강제 mock 해제

n = 0


def ok(name, cond):
    global n
    assert cond, name
    n += 1
    print("PASS", name)


ncst = json.dumps({"response": {"header": {"resultCode": "00", "resultMsg": "NORMAL_SERVICE"}, "body": {"dataType": "JSON", "items": {"item": [
    {"category": "T1H", "obsrValue": "21.3"}, {"category": "WSD", "obsrValue": "6.2"}, {"category": "VEC", "obsrValue": "250"},
    {"category": "RN1", "obsrValue": "0"}, {"category": "REH", "obsrValue": "80"}, {"category": "PTY", "obsrValue": "0"}]}}}})
w = kma.normalize_ncst(base.parse_data_go_kr_json(ncst))
ok("초단기실황 파싱", w["temp"] == 21.3 and w["wind"] == 6.2 and w["gust"] == 8.7 and w["precip"] == 0)
fc = [{"fcstDate": "20260930", "fcstTime": "1500", "category": c, "fcstValue": v} for c, v in
      [("TMP", "22"), ("WSD", "7.1"), ("VEC", "300"), ("PCP", "1.0mm"), ("POP", "60"), ("WAV", "1.5"), ("SKY", "4"), ("PTY", "1")]]
h = kma.normalize_fcst(fc)
ok("단기예보 파싱(파고 WAV 포함)", h[0]["wave"] == 1.5 and h[0]["precip"] == 1.0 and h[0]["time"] == "2026-09-30T15:00")
ok("강수 문자열 해석", kma.parse_precip("강수없음") == 0 and kma.parse_precip("1mm 미만") == 0.5 and kma.parse_precip("30.0~50.0mm") == 50.0)
err = '<OpenAPI_ServiceResponse><cmmMsgHeader><errMsg>SERVICE ERROR</errMsg><returnAuthMsg>SERVICE_KEY_IS_NOT_REGISTERED_ERROR</returnAuthMsg><returnReasonCode>30</returnReasonCode></cmmMsgHeader></OpenAPI_ServiceResponse>'
try:
    base.parse_data_go_kr_json(err)
    ok("키 미등록 오류 감지", False)
except base.ApiError as e:
    ok("키 미등록 오류 감지 (코드 30)", "30" in str(e))
pwn = [{"tmFc": "202609301000", "t6": "o 강풍주의보 : 인천(옹진), 경기도(안산)\r\no 풍랑주의보 : 인천·경기남부앞바다, 서해중부안쪽먼바다\r\n"}]
parsed = kma.parse_pwn_status(pwn)
ok("특보현황 파싱", [p["name"] for p in parsed] == ["강풍주의보", "풍랑주의보"])
ok("파출소 특보구역 매칭", kma.match_warnings(parsed, ["인천·경기남부앞바다", "옹진"]) == ["강풍주의보", "풍랑주의보"])
ok("다른 해역 미매칭", kma.match_warnings(parsed, ["충남북부앞바다", "태안"]) == [])
ok("발표시각: 단기예보 02시 이전 → 전날 23시", kma.base_vilage(__import__("datetime").datetime(2026, 9, 30, 1, 0)) == ("20260929", "2300"))
ok("발표시각: 초단기실황 10:20 → 09시", kma.base_ncst(__import__("datetime").datetime(2026, 9, 30, 10, 20)) == ("20260930", "0900"))
hl = khoa.parse_hilo([{"obsvtrNm": "인천", "predcDt": "2026-09-30 04:12", "predcTdlvVl": "812", "extrSe": "1"},
                      {"obsvtrNm": "인천", "predcDt": "2026-09-30 10:31", "predcTdlvVl": "105", "extrSe": "2"}])
ok("조석 고·저조 파싱", hl[0]["type"] == "고조" and hl[1]["type"] == "저조" and hl[1]["level_cm"] == 105)
hl2 = khoa.parse_hilo([{"tph_time": "2026-09-30 04:12:00", "tph_level": "812"}, {"tph_time": "2026-09-30 10:31:00", "tph_level": "105"},
                       {"tph_time": "2026-09-30 16:40:00", "tph_level": "790"}])
ok("조석 유형코드 없을 때 자동 판정", [e["type"] for e in hl2] == ["고조", "저조", "고조"])
ok("조석 mock 하루 3~4회", 3 <= len(khoa.mock_hilo("20260930")) <= 5)
xml = "<response><header><resultCode>00</resultCode></header><body><items><item><sunrise>0625  </sunrise><sunset>1818  </sunset><civilm>0600</civilm><civile>1843</civile></item></items></body></response>"
ok("천문연 XML 파싱", astro.parse_xml(xml) == {"sunrise": "06:25", "sunset": "18:18", "civil_dawn": "06:00", "civil_dusk": "18:43"})
vw = json.dumps({"response": {"status": "OK", "result": {"featureCollection": {"type": "FeatureCollection", "features": [
    {"type": "Feature", "properties": {"prh_lbl_1": "P73A"}, "geometry": {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]}}]}}}})
ok("브이월드 데이터 파싱", len(vworld.parse_data_response(vw)["features"]) == 1)
ok("브이월드 NOT_FOUND → 빈 목록", vworld.parse_data_response('{"response":{"status":"NOT_FOUND"}}')["features"] == [])
ok("레이어명 추출", vworld._name({"prh_lbl_1": "P73A"}) == "P73A")
ok("키 마스킹", base.mask("3776f493068994a8f2995aa1d595252153fac4d1bf44e414a964fd1323662e5a") == "3776********2e5a")
# 장애 대체: live 실패 → mock-fallback, 이후 성공 캐시 → stale
r = base.call("t_svc", "k1", 60, lambda: (_ for _ in ()).throw(base.ApiError("down")), lambda: {"v": "mock"}, True)
ok("장애 시 mock-fallback", r["_meta"]["source"] == "mock-fallback")
base.FAIL_UNTIL.clear()
base.call("t_svc", "k2", 0, lambda: {"v": "live"}, lambda: {"v": "mock"}, True)
r = base.call("t_svc", "k2", 0, lambda: (_ for _ in ()).throw(base.ApiError("down")), lambda: {"v": "mock"}, True)
ok("장애 시 최근값(stale) 표시", r["_meta"]["source"] == "stale" and r["v"] == "live")
r = base.call("t_svc", "k2", 0, lambda: {"v": "never"}, lambda: {"v": "mock"}, True)
ok("서킷 브레이커: 실패 직후 60초간 외부 호출 생략", r["_meta"]["source"] == "stale" and "재시도 대기" in r["_meta"]["error"])
ok("URL 조립(serviceKey 인코딩 보존)", "serviceKey=ab%2Bc" in base.build_url("http://x", {"serviceKey": "ab%2Bc"}))
print(f"\n{n}건 통과")
