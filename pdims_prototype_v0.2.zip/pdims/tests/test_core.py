"""핵심 로직 테스트: python tests/test_core.py"""
import os
import sys
from pathlib import Path
os.environ["PDIMS_FORCE_MOCK"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import geo, services  # noqa: E402
from app.core import judge as J, routes, jurisdiction  # noqa: E402
from app.core.simulator import SimManager  # noqa: E402

D = {d["id"]: d for d in services.drones()}
passed = 0


def ok(name, cond):
    global passed
    assert cond, name
    passed += 1
    print("PASS", name)


ok("기상청 격자: 서울 (60,127)", geo.latlon_to_grid(37.5665, 126.9780) == (60, 127))
calm = {"wind": 3, "gust": 4.2, "precip": 0, "temp": 20, "visibility_km": 10, "wave": 0.5}
ok("평온 → GO", J.judge(calm, D["D-M3E"])["result"] == "GO")
storm = {"wind": 15, "gust": 21, "precip": 8, "temp": 20, "visibility_km": 1, "wave": 3}
j = J.judge(storm, D["D-M3E"], warnings=["풍랑경보"])
ok("폭풍 → NO_GO 5항목 이상", j["result"] == "NO_GO" and sum(i["status"] == "NO_GO" for i in j["items"]) >= 5)
ok("80% 초과 → CAUTION", J.judge({**calm, "wind": 8.5}, D["D-M3E"])["result"] == "CAUTION")
ok("야간·야간불가 기종 → NO_GO", J.judge(calm, D["D-M3E"], night=True)["result"] == "NO_GO")
ok("야간·야간가능 기종 → CAUTION", J.judge(calm, D["D-M30T"], night=True)["result"] == "CAUTION")
ok("시정 미연계 → CAUTION(보수)", J.judge({**calm, "visibility_km": None}, D["D-M30T"])["result"] == "CAUTION")
ok("함정 파고 초과 → NO_GO", J.judge({**calm, "wave": 1.8}, D["D-M30T"], ship_based=True)["result"] == "NO_GO")

pts = [(37.25, 126.40), (37.20, 126.50), (37.26, 126.45), (37.21, 126.41)]
order = routes.tsp_route((37.25, 126.47), pts)
ok("TSP 모든 지점 방문", sorted(order) == [0, 1, 2, 3])
ss = routes.expanding_square(37.2, 126.4, 200, 6)
legs = [round(geo.haversine(*ss[i], *ss[i + 1])) for i in range(6)]
ok("확대사각 다리 S,S,2S,2S,3S,3S", legs == [200, 200, 400, 400, 600, 600])
ok("부채꼴 10점", len(routes.search_pattern("VS", 37.2, 126.4, radius=800)) == 10)
ok("평행탐색 생성", len(routes.search_pattern("PS", 37.2, 126.4, spacing=500, width=2000, length=2000)) >= 8)

lk = jurisdiction.lookup(37.25, 126.54)
ok("공동관할 판별(영흥·대부) 주관=영흥", lk["joint"] and lk["primary"]["id"] == "ST-YH")
ok("관할 외 해역", jurisdiction.lookup(37.0, 125.5)["primary"] is None)
p = services.plan_mission({"type": "route", "station": "ST-YH", "drone": "D-M30T", "route_id": "RT-AM-02"})
ok("RT-AM-02 관할 이탈 경고", any(i["type"] == "관할" for i in p["validation"]["issues"]))
p2 = services.plan_mission({"type": "patrol", "station": "ST-YH", "drone": "D-M30T", "hazard_ids": ["HZ-02", "HZ-03", "HZ-05"]})
ok("위험구역 순찰 계획(인접 3지점) GO/CAUTION", p2["validation"]["result"] in ("GO", "CAUTION"))
p3 = services.plan_mission({"type": "patrol", "station": "ST-YH", "drone": "D-M3E", "hazard_ids": ["HZ-01", "HZ-02", "HZ-03", "HZ-04", "HZ-05", "HZ-06", "HZ-07"], "hover_s": 180})
ok("과다 지점 → 배터리 NO_GO", p3["validation"]["result"] == "NO_GO")
fake_air = {"features": [{"type": "Feature", "properties": {"_kind": "비행금지구역", "_name": "P-TEST"},
                          "geometry": {"type": "Polygon", "coordinates": [[[126.44, 37.22], [126.46, 37.22], [126.46, 37.28], [126.44, 37.28], [126.44, 37.22]]]}}]}
v = routes.validate([(37.25, 126.40), (37.25, 126.50)], D["D-M30T"], {"lat": 37.25, "lon": 126.40}, airspace=fake_air)
ok("공역 지오펜스: 비행금지구역 통과 → NO_GO", v["result"] == "NO_GO" and any(i["type"] == "공역" for i in v["issues"]))

sim = SimManager()
m = sim.create(plan=p2, drone=D["D-M30T"], station=services.station("ST-YH"), wind=5, wind_dir=270, event_rate=0.0)
sim.run_offline(m.id)
ok(f"시뮬레이터 임무 완주·착륙 ({m.t:.0f}s, 잔량 {m.batt:.0f}%)", m.state == "LANDED" and m.batt > 15)
m2 = sim.create(plan={"waypoints": [[37.25, 126.20]]}, drone=D["D-M3E"], station=services.station("ST-YH"), event_rate=0.0)
sim.run_offline(m2.id)
ok("통신 두절 → 자동 귀환·착륙", m2.state == "LANDED" and any("통신 두절" in a["msg"] for a in m2.alerts))
m3 = sim.create(plan={"waypoints": [[37.30, 126.47], [37.20, 126.47]] * 20}, drone=D["D-M3E"], station=services.station("ST-YH"), event_rate=0.0)
sim.run_offline(m3.id)
ok("배터리 15% 자동 귀환", any("배터리 15%" in a["msg"] for a in m3.alerts))
r = services.schedule_rec("ST-YH", "D-M30T", 72, 2, "hazard")
ok("72시간 일정 추천 TOP≤3", len(r["hours"]) == 72 and 1 <= len(r["top"]) <= 3)
c = services.conditions("ST-YH")
ok("종합 기상(mock) 물때·일출몰", c["tide"]["events"] and c["sun"]["sunrise"])
print(f"\n{passed}건 통과")
