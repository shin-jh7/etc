/* PDIMS 프로토타입 v0.2 프런트엔드 (OpenLayers 9) */
"use strict";
const S = { cfg: null, stations: [], drones: [], station: null, drone: null,
  clickMode: "lookup", selHazards: new Set(), datum: null, plan: null, missions: {}, tileErr: 0 };
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const badge = (s) => `<span class="b ${esc(s)}">${esc(({ GO: "가능", CAUTION: "주의", NO_GO: "불가" })[s] || s)}</span>`;
const src = (m) => (m && m.source) ? `<span class="b ${esc(m.source)}" title="${esc(m.error || "")}">${esc(m.source)}${m.collected_at ? " " + esc(m.collected_at) : ""}</span>` : "";

async function api(path, opt) {
  const r = await fetch(path, opt);
  if (!r.ok) {
    let t = await r.text();
    try { t = JSON.parse(t).detail; } catch (e) { /* keep text */ }
    throw new Error(t);
  }
  return r.json();
}
const post = (path, body) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
const ll = (lat, lon) => ol.proj.fromLonLat([lon, lat]);
const info = (html) => { $("infoBar").innerHTML = html; };

/* ---------------- 지도 ---------------- */
function vworldSource(layer) {
  const ext = layer === "Satellite" ? "jpeg" : "png";
  const url = S.cfg.tile_mode === "direct" && S.cfg.vworld_key
    ? `https://api.vworld.kr/req/wmts/1.0.0/${S.cfg.vworld_key}/${layer}/{z}/{y}/{x}.${ext}`
    : `/api/vworld/tile/${layer}/{z}/{y}/{x}`;
  const s = new ol.source.XYZ({ url: url, maxZoom: 19, crossOrigin: "anonymous", attributions: "© VWorld" });
  s.on("tileloaderror", () => {
    S.tileErr += 1;
    if (S.tileErr === 8) {
      info("브이월드 타일 로딩 실패가 반복되어 OSM으로 전환했습니다. 연계 탭에서 오류 내용을 확인하세요.");
      $("selBase").value = "OSM";
      setBase("OSM");
    }
  });
  return s;
}
const baseLayer = new ol.layer.Tile();
const hybridLayer = new ol.layer.Tile({ visible: false });
function setBase(v) {
  if (v === "OSM" || !S.cfg.vworld_enabled) {
    baseLayer.setSource(new ol.source.OSM());
    hybridLayer.setVisible(false);
    return;
  }
  baseLayer.setSource(vworldSource(v));
  if (v === "Satellite") {
    hybridLayer.setSource(vworldSource("Hybrid"));
    hybridLayer.setVisible(true);
  } else {
    hybridLayer.setVisible(false);
  }
}

const vec = () => new ol.source.Vector();
const L = {
  admin: new ol.layer.Vector({ source: vec(), visible: false, style: (f) => new ol.style.Style({
    stroke: new ol.style.Stroke({ color: "#6b7280", width: 1, lineDash: [2, 3] }),
    text: new ol.style.Text({ text: f.get("_name") || "", font: "11px sans-serif", fill: new ol.style.Fill({ color: "#374151" }), overflow: false }) }) }),
  air: new ol.layer.Vector({ source: vec(), style: (f) => {
    const k = f.get("_kind");
    const c = k === "비행금지구역" ? "185,28,28" : (k === "비행제한구역" || k === "위험구역") ? "180,83,9" : "37,99,235";
    return new ol.style.Style({ stroke: new ol.style.Stroke({ color: `rgba(${c},0.9)`, width: 1.5 }), fill: new ol.style.Fill({ color: `rgba(${c},0.08)` }),
      text: new ol.style.Text({ text: `${k}\n${f.get("_name") || ""}`, font: "11px sans-serif", fill: new ol.style.Fill({ color: `rgb(${c})` }) }) });
  } }),
  jur: new ol.layer.Vector({ source: vec(), style: (f) => {
    const mine = S.station && f.get("id") === S.station.id;
    return new ol.style.Style({
      stroke: new ol.style.Stroke({ color: mine ? "#2563eb" : "#64748b", width: mine ? 3 : 1.5, lineDash: mine ? undefined : [6, 4] }),
      fill: new ol.style.Fill({ color: mine ? "rgba(37,99,235,0.10)" : "rgba(100,116,139,0.05)" }),
      text: new ol.style.Text({ text: f.get("name"), font: "bold 12px sans-serif", fill: new ol.style.Fill({ color: mine ? "#1d4ed8" : "#475569" }), stroke: new ol.style.Stroke({ color: "#fff", width: 3 }) }) });
  } }),
  hz: new ol.layer.Vector({ source: vec(), style: (f) => {
    const sel = S.selHazards.has(f.get("id"));
    return new ol.style.Style({ image: new ol.style.RegularShape({ points: 3, radius: sel ? 10 : 7, fill: new ol.style.Fill({ color: sel ? "#b91c1c" : "#f59e0b" }), stroke: new ol.style.Stroke({ color: "#fff", width: 1.5 }) }),
      text: new ol.style.Text({ text: f.get("name"), offsetY: -14, font: "11px sans-serif", stroke: new ol.style.Stroke({ color: "#fff", width: 3 }) }) });
  } }),
  rt: new ol.layer.Vector({ source: vec(), style: new ol.style.Style({ stroke: new ol.style.Stroke({ color: "#0891b2", width: 2, lineDash: [8, 5] }) }) }),
  mis: new ol.layer.Vector({ source: vec(), style: (f) => f.get("kind") === "out"
    ? new ol.style.Style({ image: new ol.style.Circle({ radius: 7, stroke: new ol.style.Stroke({ color: "#b91c1c", width: 3 }) }) })
    : f.get("kind") === "datum"
      ? new ol.style.Style({ image: new ol.style.RegularShape({ points: 4, radius: 9, angle: Math.PI / 4, stroke: new ol.style.Stroke({ color: "#7c3aed", width: 3 }) }) })
      : new ol.style.Style({ stroke: new ol.style.Stroke({ color: "#7c3aed", width: 3 }) }) }),
  trk: new ol.layer.Vector({ source: vec(), style: (f) => {
    const k = f.get("kind");
    if (k === "track") return new ol.style.Style({ stroke: new ol.style.Stroke({ color: "#dc2626", width: 2 }) });
    if (k === "event") return new ol.style.Style({ image: new ol.style.Circle({ radius: 6, fill: new ol.style.Fill({ color: "#dc2626" }) }), text: new ol.style.Text({ text: f.get("label"), offsetY: -12, font: "11px sans-serif", stroke: new ol.style.Stroke({ color: "#fff", width: 3 }) }) });
    return new ol.style.Style({ image: new ol.style.Circle({ radius: 8, fill: new ol.style.Fill({ color: "#111827" }), stroke: new ol.style.Stroke({ color: "#fff", width: 2 }) }), text: new ol.style.Text({ text: f.get("label"), offsetY: -16, font: "bold 11px sans-serif", stroke: new ol.style.Stroke({ color: "#fff", width: 3 }) }) });
  } }),
  st: new ol.layer.Vector({ source: vec(), style: (f) => new ol.style.Style({ image: new ol.style.Circle({ radius: 6, fill: new ol.style.Fill({ color: "#1d4ed8" }), stroke: new ol.style.Stroke({ color: "#fff", width: 2 }) }),
    text: new ol.style.Text({ text: f.get("name"), offsetY: 14, font: "11px sans-serif", stroke: new ol.style.Stroke({ color: "#fff", width: 3 }) }) }) }),
};
const map = new ol.Map({ target: "map", layers: [baseLayer, hybridLayer, L.admin, L.jur, L.air, L.rt, L.hz, L.mis, L.st, L.trk],
  view: new ol.View({ center: ll(37.25, 126.5), zoom: 11 }) });
const gj = new ol.format.GeoJSON({ featureProjection: "EPSG:3857" });
const line = (pts, props) => new ol.Feature({ geometry: new ol.geom.LineString(pts.map((p) => ll(p[0], p[1]))), ...(props || {}) });
const point = (lat, lon, props) => new ol.Feature({ geometry: new ol.geom.Point(ll(lat, lon)), ...(props || {}) });

function extentBbox() {
  const e = ol.proj.transformExtent(map.getView().calculateExtent(map.getSize()), "EPSG:3857", "EPSG:4326");
  return e.map((v) => v.toFixed(4)).join(",");
}
let moveTimer = null;
map.on("moveend", () => {
  clearTimeout(moveTimer);
  moveTimer = setTimeout(loadDynamicLayers, 400);
});
async function loadDynamicLayers() {
  const z = map.getView().getZoom();
  if (L.air.getVisible() && z >= 9) {
    try {
      const fc = await api("/api/airspace?bbox=" + extentBbox());
      L.air.getSource().clear();
      L.air.getSource().addFeatures(gj.readFeatures(fc));
    } catch (e) { info("공역 조회 실패: " + esc(e.message)); }
  }
  if (L.admin.getVisible() && z >= 10) {
    try {
      const fc = await api("/api/admin-boundary?level=sigungu&bbox=" + extentBbox());
      L.admin.getSource().clear();
      L.admin.getSource().addFeatures(gj.readFeatures(fc));
    } catch (e) { info("행정경계 조회 실패: " + esc(e.message)); }
  }
}
document.querySelectorAll("#layerPanel input").forEach((el) => {
  el.addEventListener("change", () => {
    L[el.dataset.layer].setVisible(el.checked);
    loadDynamicLayers();
  });
});

map.on("singleclick", async (evt) => {
  const [lon, lat] = ol.proj.toLonLat(evt.coordinate);
  if (S.clickMode === "hazard") {
    const f = map.forEachFeatureAtPixel(evt.pixel, (x) => x, { layerFilter: (l) => l === L.hz });
    if (f) {
      const id = f.get("id");
      if (S.selHazards.has(id)) S.selHazards.delete(id); else S.selHazards.add(id);
      L.hz.changed();
      renderMisParams();
    }
    return;
  }
  if (S.clickMode === "datum") {
    S.datum = [lat, lon];
    L.mis.getSource().clear();
    L.mis.getSource().addFeature(point(lat, lon, { kind: "datum" }));
    renderMisParams();
    return;
  }
  const air = map.forEachFeatureAtPixel(evt.pixel, (x) => x, { layerFilter: (l) => l === L.air });
  info(`조회 중… (${lat.toFixed(5)}, ${lon.toFixed(5)})`);
  try {
    const [j, a] = await Promise.all([api(`/api/jurisdictions/lookup?lat=${lat}&lon=${lon}`), api(`/api/revgeocode?lat=${lat}&lon=${lon}`)]);
    let h = `<b>${lat.toFixed(5)}, ${lon.toFixed(5)}</b> · `;
    if (!j.primary) h += "관할 파출소 없음(관할 외 해역)";
    else h += `관할: <b>${esc(j.primary.name)}</b> (${esc(j.primary.office || "")})` + (j.joint ? ` · 공동관할: ${j.all.map((x) => esc(x.name)).join(", ")} <small>${esc(j.rule)}</small>` : "");
    h += `<br>주소: ${esc((a.addresses || []).join(" / ") || "-")} ${src(a._meta)}`;
    if (air) h += `<br>공역: <b>${esc(air.get("_kind"))}</b> ${esc(air.get("_name"))}`;
    info(h);
  } catch (e) { info("조회 실패: " + esc(e.message)); }
});

/* ---------------- 초기화 ---------------- */
async function init() {
  S.cfg = await api("/api/config");
  if (S.cfg.force_mock) $("mockBadge").innerHTML = '<span class="b mock">MOCK 모드</span>';
  if (!S.cfg.vworld_enabled) $("selBase").value = "OSM";
  setBase($("selBase").value);
  S.stations = await api("/api/stations");
  $("selStation").innerHTML = S.stations.map((s) => `<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("");
  $("selStation").value = S.cfg.default_station;
  await loadDrones();
  L.jur.getSource().addFeatures(gj.readFeatures(await api("/api/jurisdictions")));
  L.hz.getSource().addFeatures(gj.readFeatures(await api("/api/hazards")));
  S.stations.forEach((s) => L.st.getSource().addFeature(point(s.lat, s.lon, { name: s.name })));
  S.routes = await api("/api/routes");
  S.routes.forEach((r) => L.rt.getSource().addFeature(line(r.waypoints, { id: r.id })));
  selectStation();
  connectWS();
}
async function loadDrones() {
  S.drones = await api("/api/drones");
  const cur = $("selDrone").value;
  $("selDrone").innerHTML = S.drones.map((d) => `<option value="${esc(d.id)}">${esc(d.name)}</option>`).join("");
  if (cur && S.drones.some((d) => d.id === cur)) $("selDrone").value = cur;
  S.drone = $("selDrone").value;
  renderDrones();
}
function selectStation() {
  S.station = S.stations.find((s) => s.id === $("selStation").value) || S.stations[0];
  L.jur.changed();
  const f = L.jur.getSource().getFeatures().find((x) => x.get("id") === S.station.id);
  if (f) map.getView().fit(f.getGeometry().getExtent(), { padding: [40, 40, 40, 40], duration: 300 });
  else map.getView().animate({ center: ll(S.station.lat, S.station.lon), zoom: 11 });
  renderMisParams();
  loadJudge();
}
$("selStation").onchange = selectStation;
$("selDrone").onchange = () => { S.drone = $("selDrone").value; loadJudge(); };
$("selBase").onchange = () => { S.tileErr = 0; setBase($("selBase").value); };
document.querySelectorAll("#tabs button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("on", x === b));
    document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("on", x.id === "tab-" + b.dataset.tab));
    if (b.dataset.tab === "link") loadLink();
  };
});
async function doSearch() {
  const q = $("txtSearch").value.trim();
  if (!q) return;
  try {
    const r = await api(`/api/search?q=${encodeURIComponent(q)}&kind=place`);
    let items = r.items || [];
    if (!items.length) {
      const g = await api(`/api/geocode?q=${encodeURIComponent(q)}`);
      if (g.lat) items = [{ title: q, address: g.refined || q, lat: g.lat, lon: g.lon }];
    }
    if (!items.length) { info("검색 결과 없음 " + src(r._meta)); return; }
    map.getView().animate({ center: ll(items[0].lat, items[0].lon), zoom: 15 });
    info("검색 결과: " + items.slice(0, 5).map((it, i) => `<a href="#" data-i="${i}">${esc(it.title)}</a> <small>${esc(it.address || "")}</small>`).join(" · ") + " " + src(r._meta));
    $("infoBar").querySelectorAll("a").forEach((a) => {
      a.onclick = (e) => { e.preventDefault(); const it = items[+a.dataset.i]; map.getView().animate({ center: ll(it.lat, it.lon), zoom: 15 }); };
    });
  } catch (e) { info("검색 실패: " + esc(e.message)); }
}
$("btnSearch").onclick = doSearch;
$("txtSearch").onkeydown = (e) => { if (e.key === "Enter") doSearch(); };

/* ---------------- 운항판정 ---------------- */
async function loadJudge() {
  if (!S.station || !S.drone) return;
  $("judgeBox").innerHTML = "판정 중…";
  try {
    const j = await api(`/api/judge?station=${S.station.id}&drone=${S.drone}`);
    const c = j.conditions, w = c.weather, s = c.sources;
    const color = { GO: "#15803d", CAUTION: "#b45309", NO_GO: "#b91c1c" }[j.result];
    let h = `<div class="big" style="background:${color}">${({ GO: "운항 가능", CAUTION: "운항 주의", NO_GO: "운항 불가" })[j.result]}</div>`;
    if (j.low_confidence) h += ' <span class="b stale">데이터 신뢰도 낮음(추정·지연 포함)</span>';
    h += `<table><tr><th>항목</th><th>값</th><th>판정</th><th>사유</th></tr>` + j.items.map((it) =>
      `<tr><td>${esc(it.item)}</td><td class="num">${esc(it.value == null ? "-" : it.value)}</td><td>${badge(it.status)}</td><td>${esc(it.reason)}</td></tr>`).join("") + "</table>";
    $("judgeBox").innerHTML = h;
    const nxt = (c.tide.upcoming || []).map((e) => `${e.type} ${e.time.slice(11)} (${e.level_cm == null ? "-" : e.level_cm}cm)`).join("<br>") || "-";
    $("condBox").innerHTML = `<div class="cards">
      <div class="card"><div class="l">풍속/풍향</div><div class="v">${w.wind ?? "-"} m/s</div><small>${w.wind_dir ?? "-"}° · 순간 ${w.gust ?? "-"}(추정)</small></div>
      <div class="card"><div class="l">기온/습도</div><div class="v">${w.temp ?? "-"}℃</div><small>${w.humidity ?? "-"}%</small></div>
      <div class="card"><div class="l">강수(1h)</div><div class="v">${w.precip ?? "-"} mm</div><small>PTY ${esc(w.pty ?? "-")}</small></div>
      <div class="card"><div class="l">파고(예보)</div><div class="v">${w.wave ?? "-"} m</div><small>단기예보 WAV</small></div>
      <div class="card"><div class="l">일출/일몰</div><div class="v">${esc(c.sun.sunrise || "-")} / ${esc(c.sun.sunset || "-")}</div><small>박명 ${esc(c.sun.civil_dawn || "-")}~${esc(c.sun.civil_dusk || "-")}</small></div>
      <div class="card"><div class="l">다음 물때 (${esc(c.tide.obs_code || "-")})</div><div style="font-size:12px">${nxt}</div></div>
    </div>
    <div>기상특보: ${c.warnings.length ? c.warnings.map((x) => `<span class="b NO_GO">${esc(x)}</span>`).join(" ") : "해당 구역 발효 없음"}</div>
    <table><tr><th>정보</th><th>출처 상태</th></tr>
      <tr><td>초단기실황 (기상청)</td><td>${src(s.weather)}</td></tr><tr><td>기상특보 (기상청)</td><td>${src(s.warnings)}</td></tr>
      <tr><td>출몰시각 (천문연)</td><td>${src(s.sun)}</td></tr><tr><td>조석예보 (국립해양조사원)</td><td>${src(s.tide)}</td></tr></table>
    <small>live=실연계 · stale=장애로 최근값 표시 · mock=모의 데이터. 순간풍속·시정은 현재 연계 API 미제공(추정/보수 판정).</small>`;
  } catch (e) { $("judgeBox").innerHTML = "판정 실패: " + esc(e.message); }
}

/* ---------------- 일정 추천 ---------------- */
$("btnSched").onclick = async () => {
  $("schedBox").innerHTML = "계산 중…";
  try {
    const r = await api(`/api/schedule?station=${S.station.id}&drone=${S.drone}&hours=${$("schHours").value}&duration=${$("schDur").value}&mission=${$("schType").value}`);
    const col = (x) => x.result === "NO_GO" ? "#b91c1c" : x.result === "CAUTION" ? "#d97706" : `rgba(21,128,61,${0.4 + x.score / 170})`;
    let h = `<b>추천 TOP ${r.top.length}</b><table><tr><th>#</th><th>시작</th><th>종료</th><th>판정</th><th class="num">적합도</th></tr>` +
      r.top.map((t, i) => `<tr><td>${i + 1}</td><td>${esc(t.start.replace("T", " "))}</td><td>${esc(t.end.slice(11))}</td><td>${badge(t.result)}</td><td class="num">${t.score}</td></tr>`).join("") + "</table>";
    h += `<b>시간별 적합도</b> <small>(빨강=불가, 주황=주의, 초록 진할수록 적합)</small>`;
    for (let i = 0; i < r.hours.length; i += 24) {
      const day = r.hours.slice(i, i + 24);
      h += `<div><small>${esc(day[0].time.slice(0, 10))} ${esc(day[0].time.slice(11, 13))}시~</small></div><div class="heat">` +
        day.map((x) => `<div style="background:${col(x)}" title="${esc(x.time)} ${x.result} ${x.score}점 풍속${x.wind} 파고${x.wave}\n${esc(x.reasons.join("\n"))}">${esc(x.time.slice(11, 13))}</div>`).join("") + "</div>";
    }
    h += `<small>출처: 예보 ${src(r.sources.forecast)} 조석 ${src(r.sources.tide)} 특보 ${src(r.sources.warnings)}</small>`;
    $("schedBox").innerHTML = h;
  } catch (e) { $("schedBox").innerHTML = "실패: " + esc(e.message); }
};

/* ---------------- 임무 계획 ---------------- */
$("misType").onchange = () => { S.selHazards.clear(); S.datum = null; L.hz.changed(); L.mis.getSource().clear(); renderMisParams(); };
function renderMisParams() {
  const t = $("misType").value;
  S.clickMode = t === "patrol" ? "hazard" : t === "search" ? "datum" : "lookup";
  let h = "";
  if (t === "route") {
    const rs = (S.routes || []).filter((r) => !S.station || r.station === S.station.id);
    h = `<label>표준경로 <select id="misRoute">${rs.map((r) => `<option value="${esc(r.id)}">${esc(r.id)} ${esc(r.name)}</option>`).join("")}</select></label>`;
  } else if (t === "patrol") {
    h = `<div>선택 지점: ${S.selHazards.size ? [...S.selHazards].map(esc).join(", ") : "<i>지도에서 위험지점(삼각형)을 클릭하세요</i>"}</div>
      <label>지점별 체공(초) <input id="misHover" type="number" value="60" style="width:60px"></label>`;
  } else {
    h = `<div>기준점(Datum): ${S.datum ? S.datum.map((v) => v.toFixed(5)).join(", ") : "<i>지도를 클릭하세요</i>"}</div>
      <div class="row"><label>패턴 <select id="misPat"><option value="SS">확대사각(SS)</option><option value="VS">부채꼴(VS)</option><option value="PS">평행(PS)</option><option value="CS">횡단(CS)</option></select></label>
      <label>간격 <input id="misSp" type="number" value="200" style="width:60px">m</label>
      <label>다리수 <input id="misLegs" type="number" value="12" style="width:48px"></label>
      <label>반경 <input id="misRad" type="number" value="1000" style="width:60px">m</label>
      <label>폭×길이 <input id="misW" type="number" value="2000" style="width:60px">×<input id="misLen" type="number" value="2000" style="width:60px">m</label>
      <label>기준방위 <input id="misBrg" type="number" value="0" style="width:48px">°</label></div>`;
  }
  $("misParams").innerHTML = h;
}
$("btnPlan").onclick = async () => {
  const t = $("misType").value;
  const req = { type: t, station: S.station.id, drone: S.drone, alt_m: +$("misAlt").value };
  if (t === "route") req.route_id = $("misRoute").value;
  if (t === "patrol") { req.hazard_ids = [...S.selHazards]; req.hover_s = +$("misHover").value; }
  if (t === "search") {
    if (!S.datum) { $("planBox").innerHTML = "기준점을 먼저 지도에서 클릭하세요."; return; }
    Object.assign(req, { datum: S.datum, pattern: $("misPat").value, spacing: +$("misSp").value, legs: +$("misLegs").value,
      radius: +$("misRad").value, width: +$("misW").value, length: +$("misLen").value, bearing: +$("misBrg").value });
  }
  $("planBox").innerHTML = "경로 생성·검증 중… (공역 조회 포함)";
  try {
    const p = await post("/api/mission/plan", req);
    S.plan = p;
    const v = p.validation, e = v.estimate;
    const src2 = L.mis.getSource();
    src2.clear();
    src2.addFeature(line(p.full_path));
    if (S.datum && t === "search") src2.addFeature(point(S.datum[0], S.datum[1], { kind: "datum" }));
    v.issues.filter((i) => i.points).forEach((i) => i.points.forEach((q) => src2.addFeature(point(q.lat, q.lon, { kind: "out" }))));
    map.getView().fit(src2.getExtent(), { padding: [60, 60, 60, 60], duration: 300 });
    $("planBox").innerHTML = `<p><b>${esc(p.name)}</b> ${badge(v.result)}</p>
      <div class="cards"><div class="card"><div class="l">총 거리</div><div class="v">${(e.distance_m / 1000).toFixed(1)} km</div></div>
      <div class="card"><div class="l">예상 비행</div><div class="v">${Math.round(e.flight_s / 60)} 분</div></div>
      <div class="card"><div class="l">배터리 소모</div><div class="v">${e.battery_pct}%</div></div></div>
      ${v.issues.length ? "<table><tr><th>구분</th><th>판정</th><th>내용</th></tr>" + v.issues.map((i) => `<tr><td>${esc(i.type)}</td><td>${badge(i.level)}</td><td>${esc(i.msg)}</td></tr>`).join("") + "</table>" : "<p>검증 이상 없음</p>"}
      <small>경유점 ${p.waypoints.length}개 · 풍속 ${p.wind ?? "-"}m/s 반영 · 공역 ${src(p.airspace_source && { source: Object.values(p.airspace_source.layers || {})[0] })}</small>`;
    $("btnStart").disabled = false;
  } catch (err) { $("planBox").innerHTML = "실패: " + esc(err.message); $("btnStart").disabled = true; }
};
$("btnStart").onclick = async () => {
  if (!S.plan) return;
  if (S.plan.validation.result === "NO_GO" && !confirm("검증 결과 '불가'입니다. 시뮬레이션으로만 비행하시겠습니까?")) return;
  try {
    const m = await post("/api/sim/start", { ...S.plan, time_scale: 5 });
    S.missions[m.mission] = m;
    document.querySelector('#tabs button[data-tab="ctrl"]').click();
  } catch (e) { alert(e.message); }
};

/* ---------------- 관제 (WebSocket) ---------------- */
function connectWS() {
  const ws = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws/telemetry");
  ws.onmessage = (ev) => {
    const snaps = JSON.parse(ev.data);
    snaps.forEach((s) => { S.missions[s.mission] = s; });
    renderCtrl();
  };
  ws.onclose = () => setTimeout(connectWS, 2000);
}
async function cmd(mid, c) {
  try { await post(`/api/sim/${mid}/cmd?cmd=${encodeURIComponent(c)}`, {}); } catch (e) { alert(e.message); }
}
window.cmd = cmd;
window.delMission = async (mid) => { await api(`/api/sim/${mid}`, { method: "DELETE" }); delete S.missions[mid]; renderCtrl(); };
const trackCache = {};
function renderCtrl() {
  const ms = Object.values(S.missions);
  const src3 = L.trk.getSource();
  src3.clear();
  if (!ms.length) { $("ctrlBox").innerHTML = '<p class="muted">진행 중인 임무가 없습니다.</p>'; return; }
  $("ctrlBox").innerHTML = ms.map((m) => {
    trackCache[m.mission] = (trackCache[m.mission] || []);
    const tr = trackCache[m.mission];
    const last = tr[tr.length - 1];
    if (!last || last[0] !== m.lat || last[1] !== m.lon) tr.push([m.lat, m.lon]);
    if (tr.length > 1) src3.addFeature(line(tr, { kind: "track" }));
    src3.addFeature(point(m.lat, m.lon, { kind: "drone", label: `${m.mission} ${m.battery}%` }));
    (m.events || []).forEach((e) => src3.addFeature(point(e.lat, e.lon, { kind: "event", label: e.type })));
    const bc = m.battery <= 20 ? "NO_GO" : m.battery <= 30 ? "CAUTION" : "GO";
    return `<div class="card" style="margin-bottom:8px"><b>${esc(m.mission)}</b> ${esc(m.drone)} · <span class="b ${m.state === "RTL" ? "CAUTION" : "live"}">${esc(m.state)}</span> ${m.link ? "" : '<span class="b NO_GO">통신두절</span>'}
      <div class="cards"><div class="card"><div class="l">배터리</div><div class="v"><span class="b ${bc}">${m.battery}%</span></div></div>
      <div class="card"><div class="l">고도/경유점</div><div class="v">${m.alt}m · ${m.wp}/${m.wp_total}</div></div>
      <div class="card"><div class="l">경과(배속 ×${m.scale})</div><div class="v">${Math.floor(m.t / 60)}분 ${m.t % 60}초</div><small>${(m.dist / 1000).toFixed(1)}km</small></div></div>
      <div class="row"><button onclick="cmd('${m.mission}','pause')">일시정지</button><button onclick="cmd('${m.mission}','resume')">재개</button>
      <button onclick="cmd('${m.mission}','rtl')">귀환</button><button onclick="cmd('${m.mission}','manual')">수동</button>
      <button onclick="cmd('${m.mission}','speed:20')">×20</button><button onclick="delMission('${m.mission}')">목록 삭제</button></div>
      ${(m.alerts || []).slice().reverse().map((a) => `<div class="alert ${esc(a.level)}">[${esc(a.at)}] ${esc(a.msg)}</div>`).join("")}
      ${(m.events || []).length ? "<table><tr><th>이벤트</th><th>유형</th><th>신뢰도</th><th>위치</th></tr>" + m.events.map((e) => `<tr><td>${esc(e.id)}</td><td>${esc(e.type)}</td><td class="num">${e.confidence}</td><td>${e.lat}, ${e.lon}</td></tr>`).join("") + "</table>" : ""}
    </div>`;
  }).join("");
}

/* ---------------- 드론 ---------------- */
function renderDrones() {
  $("droneBox").innerHTML = "<table><tr><th>기종</th><th class='num'>풍속</th><th class='num'>순간</th><th>방수</th><th>야간</th><th class='num'>비행</th><th></th></tr>" +
    S.drones.map((d) => `<tr><td>${esc(d.name)}</td><td class="num">${d.limits.max_wind}</td><td class="num">${d.limits.max_gust}</td><td>${d.limits.rain_ok ? "O" : "X"}</td><td>${d.limits.night_ok ? "O" : "X"}</td><td class="num">${d.spec.endurance_min}분</td>
      <td><button onclick="delDrone('${esc(d.id)}')">삭제</button></td></tr>`).join("") + "</table>";
}
window.delDrone = async (id) => { if (confirm("삭제할까요?")) { await api(`/api/drones/${id}`, { method: "DELETE" }); loadDrones(); } };
$("btnAddDrone").onclick = async () => {
  const d = { name: $("dName").value.trim(),
    spec: { cruise_speed: +$("dSpeed").value, endurance_min: +$("dEnd").value, comm_range_m: +$("dComm").value, reserve_pct: 25 },
    limits: { max_wind: +$("dWind").value, max_gust: +$("dGust").value, rain_ok: $("dRain").value === "true", max_precip: 3,
      min_temp: -10, max_temp: 40, min_visibility_km: 3, max_wave_ship: +$("dWave").value, night_ok: $("dNight").value === "true" } };
  if (!d.name) { alert("기종명을 입력하세요"); return; }
  await post("/api/drones", d);
  loadDrones();
};

/* ---------------- 연계 ---------------- */
async function loadLink() {
  const r = await api("/api/integrations");
  const k = r.keys;
  $("linkBox").innerHTML = `<table><tr><th>설정</th><th>값</th></tr>
    <tr><td>DATA_GO_KR_KEY</td><td>${esc(k.DATA_GO_KR_KEY)}</td></tr><tr><td>VWORLD_API_KEY</td><td>${esc(k.VWORLD_API_KEY)}</td></tr>
    <tr><td>VWORLD_DOMAIN / 타일</td><td>${esc(k.VWORLD_DOMAIN)} / ${esc(k.VWORLD_TILE_MODE)}</td></tr></table>
    <table><tr><th>사이트</th><th>서비스</th><th>상태</th><th class="num">성공/호출</th><th class="num">ms</th></tr>` +
    r.services.map((s) => `<tr><td>${esc(s.site)}</td><td>${esc(s.name)}<br><small>${esc(s.use)} · ${esc(s.how)}</small>${s.last_error ? `<br><small style="color:#b91c1c">${esc(s.last_error)}</small>` : ""}</td>
      <td><span class="b ${esc(s.mode)}">${esc(s.mode)}</span></td><td class="num">${s.ok}/${s.calls}</td><td class="num">${s.avg_ms}</td></tr>`).join("") +
    "</table><small>ready=키 설정됨(아직 호출 전) · live=정상 · error=최근 호출 실패(캐시/모의로 대체) · file=파일 연계</small>";
}
$("btnLink").onclick = loadLink;

init().catch((e) => info("초기화 실패: " + esc(e.message)));
