#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
PORT="${1:-8000}"
export PYTHONUTF8=1
[ -f .env ] || { echo "[안내] .env 생성(.env.example 복사)"; cp .env.example .env; }
[ -x .venv/bin/python ] || python3 -m venv .venv
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt
.venv/bin/python -c "import app.main"
echo "http://localhost:${PORT}  (API 문서 /docs)"
exec .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --reload
