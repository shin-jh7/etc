@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
if exist ".venv\Scripts\python.exe" (.venv\Scripts\python.exe tools\check_apis.py) else (python tools\check_apis.py)
pause
