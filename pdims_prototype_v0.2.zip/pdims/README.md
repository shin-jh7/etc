# PDIMS 순찰드론 종합관리시스템 — 프로토타입 v0.2

계획서 v1.1 기준 실행형 프로토타입입니다. 이번 버전(v0.2)에서는 **공공데이터포털·브이월드 API 키를 실제로 연동**합니다.

## 1. 실행
```
run.bat            (Windows, 최초 1~3분 설치)    /  ./run.sh (Linux·macOS)
http://localhost:8000      API 문서: /docs
check_apis.bat     (연계 점검: 각 API 실호출 결과·응답 필드 출력 → cache/api_check_report.json)
```
- `.env`에 키가 들어 있습니다. **.env는 외부 공유·형상관리(git) 금지** (.gitignore 포함).
- 폐쇄망 시연: `.env`에서 `PDIMS_FORCE_MOCK=1`.

## 2. 연계 구조 (app/integrations)
| 파일 | 사이트 | 서비스 |
|---|---|---|
| kma.py | 공공데이터포털 | 기상청 단기예보(초단기실황·초단기예보·단기예보), 기상특보(getPwnStatus) |
| khoa.py | 공공데이터포털 | 국립해양조사원 조석예보(고·저조/시계열), 조위관측 실측 |
| astro.py | 공공데이터포털 | 한국천문연구원 출몰시각(getLCRiseSetInfo, XML) |
| vworld.py | 브이월드 | WMTS(Base/Satellite/Hybrid/gray/midnight), 2D데이터(행정경계·항공공역), 지오코더, 검색 |
| tools/import_stations.py | 공공데이터포털(파일) | 해양경찰청_관서현황 CSV → 브이월드 지오코더로 좌표화 |
| tools/import_hazard_shp.py | 공공데이터포털(파일) | 해양경찰청_연안위험구역현황 SHP → GeoJSON |

장애 처리: live 실패 → 최근 캐시(stale, 수집시각 표시) → 없으면 mock. 실패 후 60초간 재호출 생략(서킷 브레이커). 화면의 출처 배지(live/stale/mock)와 '연계' 탭에서 상태를 확인합니다.

## 3. 키 적용 전 확인
1. 공공데이터포털: 키 하나로 여러 서비스를 쓰지만 **서비스마다 활용신청 승인**이 필요합니다. 미승인 서비스는 `SERVICE_KEY_IS_NOT_REGISTERED_ERROR(30)`.
2. 브이월드: 키 발급 시 등록한 **서비스 URL**과 `.env`의 `VWORLD_DOMAIN`이 같아야 하며, 키 관리 화면에서 사용할 API(WMTS·2D데이터·지오코더·검색)가 체크되어 있어야 합니다. 타일이 안 뜨면 `VWORLD_TILE_MODE=direct`로 바꿔 보거나 OSM으로 전환됩니다.
3. 조위관측소 코드(obs_code)·특보구역(warn_areas)은 `data/stations.json`에서 파출소별로 관리합니다(현재 예시 값).

## 4. 테스트
```
python tests/test_core.py       # 판정·경로·수색패턴·관할·공역·시뮬레이터 등 23건
python tests/test_adapters.py   # 응답 파서·오류코드·장애 대체 21건 (네트워크 불필요)
```

## 5. 폐쇄망/프록시
`set HTTPS_PROXY=http://프록시:포트` 후 run.bat. 오프라인 설치: 인터넷 PC에서 `pip download -r requirements.txt -d wheels` → `pip install --no-index -f wheels -r requirements.txt`.

## 6. 예시 데이터 주의
`data/`의 파출소·관할 경계·위험지점·표준경로·드론 제원은 **모두 가상 예시**입니다. 실자료로 교체해야 합니다.
